\
"""Vodafone-inspired enterprise dashboard theme."""
from __future__ import annotations
import streamlit as st

BRAND_RED = "#E60000"
BRAND_INK = "#17233B"
BRAND_MUTED = "#64748B"
BRAND_SURFACE = "#F3F6FA"
BRAND_BORDER = "#E5EAF1"
ACCENT = "#4F46E5"
TASK_PALETTE = ("#E60000", "#3977D5", "#68778D", "#0F9D83", "#8B5CF6", "#1F2937", "#D97706", "#0F766E", "#4338CA", "#A16207")

_CSS = f'''
<style>
:root {{ --brand-red:{BRAND_RED}; --ink:{BRAND_INK}; --muted:{BRAND_MUTED}; --surface:{BRAND_SURFACE}; --border:{BRAND_BORDER}; }}
html, body, [class*="css"] {{ font-family: Inter, "Segoe UI", Arial, sans-serif; }}
.stApp {{ background:var(--surface); color:var(--ink); }}
[data-testid="stHeader"] {{ background:rgba(243,246,250,.92); height:2.2rem; }}
[data-testid="stDecoration"] {{ display:none; }}
[data-testid="stToolbar"] {{ right:.8rem; }}
.block-container {{ padding-top:1.25rem; padding-bottom:2rem; max-width:1680px; }}
[data-testid="stSidebar"] {{ background:#F8FAFC; border-right:1px solid var(--border); }}
[data-testid="stSidebar"] > div:first-child {{ padding-top:1.2rem; }}
.brand-title {{ color:var(--ink); font-size:1.12rem; font-weight:800; margin-top:.35rem; }}
.brand-subtitle {{ color:var(--muted); font-size:.72rem; line-height:1.45; margin:.2rem 0 1.15rem; }}
.sidebar-section-label {{ color:#8994A5; font-size:.64rem; font-weight:800; letter-spacing:.12em; margin:.7rem 0 .15rem; }}
[data-testid="stSidebar"] [role="radiogroup"] {{ gap:.25rem; }}
[data-testid="stSidebar"] [role="radiogroup"] label {{ padding:.55rem .7rem; border-radius:9px; font-weight:650; color:#34445D; }}
[data-testid="stSidebar"] [role="radiogroup"] label:has(input:checked) {{ background:#FCE7E7; color:var(--brand-red); }}
.toolbar-eyebrow {{ color:#8A96A8; font-size:.64rem; font-weight:800; letter-spacing:.13em; }}
.toolbar-project {{ color:var(--ink); font-size:1.25rem; font-weight:800; margin-top:.1rem; }}
.gantt-title {{ display:flex; align-items:center; gap:.55rem; font-size:1.4rem; font-weight:800; color:var(--ink); margin:.35rem 0 .15rem; }}
.gantt-subtitle {{ color:var(--muted); font-size:.82rem; margin-bottom:.8rem; }}
.gantt-chip {{ display:inline-block; padding:.18rem .58rem; border-radius:999px; font-size:.65rem; font-weight:750; border:1px solid var(--border); }}
.chip-dirty {{ background:#FFF4D6; color:#946200; border-color:#F7D98B; }}
.chip-saved {{ background:#E6F7ED; color:#167344; border-color:#BCE8CC; }}
.chip-role {{ background:#EEF2FF; color:#4F46E5; border-color:#D9DFFF; }}
[data-testid="stMetric"] {{ background:#fff; border:1px solid var(--border); border-radius:12px; padding:.78rem .9rem; box-shadow:0 2px 8px rgba(24,39,75,.035); }}
[data-testid="stMetricLabel"] {{ color:#77849A; font-size:.68rem; font-weight:750; text-transform:uppercase; letter-spacing:.055em; }}
[data-testid="stMetricValue"] {{ color:var(--ink); font-size:1.45rem; font-weight:800; }}
.stButton > button, .stDownloadButton > button {{ border-radius:8px; font-weight:700; border-color:#DDE3EC; min-height:2.35rem; }}
.stButton > button[kind="primary"] {{ background:var(--brand-red); border-color:var(--brand-red); }}
.stButton > button[kind="primary"]:hover {{ background:#C90000; border-color:#C90000; }}
[data-testid="stPlotlyChart"], [data-testid="stDataFrame"], [data-testid="stExpander"] {{ background:#fff; border:1px solid var(--border); border-radius:12px; overflow:hidden; }}
[data-testid="stExpander"] {{ padding:.15rem .55rem; }}\n.section-heading {{ font-size:1.02rem; font-weight:800; color:var(--ink); padding:.55rem 0 .7rem; }}\n.timeline-table-label {{ color:#8A96A8; font-size:.63rem; font-weight:800; letter-spacing:.12em; padding:.45rem .25rem; }}
hr {{ border-color:var(--border); }}
div[data-testid="stAlert"] {{ border-radius:10px; }}
footer, #MainMenu {{ visibility:hidden; }}
</style>
'''

def inject() -> None:
    st.markdown(_CSS, unsafe_allow_html=True)
