"""Reusable, stateless rendering components."""
