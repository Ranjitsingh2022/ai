"""Dashboard timeline: task register and interactive Plotly Gantt chart."""
from __future__ import annotations
import streamlit as st
from backend.domain.models import Project, ProjectStats
from app.components.gantt_figure import build_gantt_figure
from app.views.project_sidebar import DisplayOptions

def render(project: Project, stats: ProjectStats, options: DisplayOptions) -> None:
    st.markdown('<div class="section-heading">▥ &nbsp; Project Timeline</div>', unsafe_allow_html=True)
    if not project.tasks:
        st.info("Your project timeline is ready. Add tasks, load a project template, or ask the AI Planning Assistant to generate a plan.")
    else:
        table_col, chart_col = st.columns([2.25, 5.75], gap="small")
        rows = [
            {
                "#": task.ref,
                "Task": task.name,
                "Start": task.start_date.strftime("%d %b"),
                "End": task.end_date.strftime("%d %b"),
                "Dur": f"{task.duration_days}d" if not task.is_milestone else "◆",
            }
            for task in project.tasks
        ]
        with table_col:
            st.markdown('<div class="timeline-table-label">TASK REGISTER</div>', unsafe_allow_html=True)
            st.dataframe(rows, hide_index=True, width="stretch", height=min(620, max(270, len(rows) * 36 + 42)))
        with chart_col:
            st.markdown('<div class="timeline-table-label">SCHEDULE</div>', unsafe_allow_html=True)
            figure = build_gantt_figure(
                project,
                critical_path=stats.critical_path_refs if options.show_critical_path else (),
                show_dependencies=options.show_dependencies,
                show_today=options.show_today,
            )
            st.plotly_chart(
                figure,
                width="stretch",
                config={
                    "displaylogo": False,
                    "modeBarButtonsToRemove": ["lasso2d", "select2d", "autoScale2d"],
                    "toImageButtonOptions": {
                        "filename": f"{project.name or 'project'}-timeline",
                        "format": "png", "scale": 2,
                    },
                },
            )
    legend_cols = st.columns(4)
    legend_cols[0].markdown("🔴 **Critical path**")
    legend_cols[1].markdown("🟦 **Task**")
    legend_cols[2].markdown("◆ **Milestone**")
    legend_cols[3].markdown("┄ **Today / dependency**")
    if options.show_critical_path and stats.critical_path_refs:
        st.caption("Critical path: " + " → ".join(stats.critical_path_refs))
