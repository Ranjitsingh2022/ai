"""AI planning assistant panel."""

from __future__ import annotations

import streamlit as st
from backend.domain.models import Project, ProjectRole, UserPrincipal
from backend.errors import AppError
from backend.logging_config import get_logger
from backend.services.ai_service import ChatMessage

from app.bootstrap import get_container
from app.session import session

logger = get_logger(__name__)

_WELCOME = (
    "Describe what you want to plan or change — scope, team and target dates — and "
    "I will draft a dependency-aware timeline. You can also ask me to adjust the "
    "current chart."
)


def render(project: Project, principal: UserPrincipal, role: ProjectRole) -> None:
    container = get_container()

    with st.expander("✦  AI Planning Assistant", expanded=True):
        if not container.ai.enabled:
            st.info(
                "The AI assistant is disabled in the configuration file (llm.enabled = false). "
                "Everything else in the application continues to work."
            )
            return

        header, actions = st.columns([5, 1])
        header.caption(_WELCOME)
        if actions.button("Clear chat", width="stretch"):
            session.reset_chat()
            st.rerun()

        for message in session.chat:
            if message.role == "tool":
                continue
            with st.chat_message("user" if message.role == "user" else "assistant"):
                st.markdown(message.text or "_Updated the chart._")

    if not role.can_edit:
        st.caption("Read-only access — the assistant cannot modify this project.")
        return

    prompt = st.chat_input("Ask the planning assistant…")
    if not prompt:
        return

    session.append_chat(ChatMessage(role="user", text=prompt.strip()))
    with st.spinner("Planning…"):
        _exchange(project, principal)
    st.rerun()


def _exchange(project: Project, principal: UserPrincipal) -> None:
    container = get_container()
    try:
        reply = container.ai.complete(list(session.chat), project, principal)
    except AppError as exc:
        session.append_chat(ChatMessage(role="assistant", text=str(exc)))
        return
    except Exception:  # noqa: BLE001 - never surface provider internals
        logger.exception("ai_exchange_failed")
        session.append_chat(
            ChatMessage(
                role="assistant",
                text="Something went wrong while contacting the assistant. Please try again.",
            )
        )
        return

    if reply.proposal is not None:
        updated = project.with_tasks(reply.proposal.tasks).model_copy(
            update={"name": reply.proposal.project_name or project.name}
        )
        session.set_project(updated)
        container.projects.record_ai_plan(updated, principal, len(reply.proposal.tasks))
        session.append_chat(
            ChatMessage(
                role="assistant",
                tool_name="update_gantt_chart",
                tool_args={"projectName": reply.proposal.project_name},
                text=reply.text,
            )
        )
        session.append_chat(
            ChatMessage(
                role="tool",
                tool_name="update_gantt_chart",
                tool_response={"status": "applied", "taskCount": len(reply.proposal.tasks)},
            )
        )
        return

    session.append_chat(
        ChatMessage(role="assistant", text=reply.text or "I did not catch that — could you rephrase?")
    )
