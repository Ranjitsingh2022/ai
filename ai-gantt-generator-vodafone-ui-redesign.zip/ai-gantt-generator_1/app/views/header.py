"""Project title and headline schedule metrics."""
from __future__ import annotations
import streamlit as st
from backend.domain.models import Project, ProjectRole, ProjectStats
from app.session import session

def render(project: Project, stats: ProjectStats, role: ProjectRole) -> None:
    status_chip = (
        '<span class="gantt-chip chip-dirty">Unsaved changes</span>' if session.dirty
        else f'<span class="gantt-chip chip-saved">Saved · v{project.version}</span>' if project.version
        else '<span class="gantt-chip chip-dirty">Draft</span>'
    )
    role_chip = f'<span class="gantt-chip chip-role">{role.value}</span>'
    st.markdown(
        f'<div class="gantt-title">{_escape(project.name)} {status_chip} {role_chip}</div>',
        unsafe_allow_html=True,
    )
    window = (
        f"{stats.start_date:%d %b %Y} → {stats.end_date:%d %b %Y}"
        if stats.start_date and stats.end_date else "No scheduled work yet"
    )
    st.markdown(f'<div class="gantt-subtitle">{_escape(project.description) if project.description else "Project schedule and delivery overview"} · {window}</div>', unsafe_allow_html=True)
    duration, tasks_col, milestones, completion, owners, overdue = st.columns(6)
    duration.metric("Duration", f"{stats.total_days} days")
    tasks_col.metric("Tasks", stats.task_count)
    milestones.metric("Milestones", stats.milestone_count)
    completion.metric("Complete", f"{stats.completion_pct}%", help=f"{sum(1 for task in project.tasks if task.progress >= 100)} of {stats.task_count} tasks completed")
    owners.metric("Owners", stats.unique_owners)
    overdue.metric("Overdue", stats.overdue_count, delta=None if not stats.overdue_count else f"-{stats.overdue_count}", delta_color="inverse")

def _escape(value: str) -> str:
    return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")
