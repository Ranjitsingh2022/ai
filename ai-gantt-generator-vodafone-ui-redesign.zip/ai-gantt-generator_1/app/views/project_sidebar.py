"""Sidebar: project lifecycle, templates, exports and display options."""

from __future__ import annotations

from dataclasses import dataclass

import streamlit as st
from backend.container import Container
from backend.domain.models import Project, ProjectRole, UserPrincipal, ViewMode
from backend.errors import AppError, ConcurrencyError
from backend.services.export_service import ExportArtifact

from app.bootstrap import get_container
from app.session import session

_VIEW_LABELS: dict[ViewMode, str] = {
    ViewMode.DAYS: "Days",
    ViewMode.WEEKS: "Weeks",
    ViewMode.WEEK_COUNT: "Week number",
    ViewMode.MONTHS: "Months",
    ViewMode.QUARTERS: "Quarters",
}

_EXPORT_FORMATS = ("PowerPoint (.pptx)", "Excel (.xlsx)", "CSV (.csv)", "JSON (.json)")


@dataclass(frozen=True, slots=True)
class DisplayOptions:
    show_dependencies: bool = True
    show_today: bool = True
    show_critical_path: bool = True


def render(project: Project, principal: UserPrincipal, role: ProjectRole) -> DisplayOptions:
    container = get_container()

    with st.sidebar:
        st.divider()
        _render_project_picker(container, principal)
        st.divider()
        _render_persistence(container, project, principal, role)
        st.divider()
        options = _render_display_options(project)
        st.divider()
        _render_exports(container, project, principal)
        _render_environment_badge(container)

    return options


# -- Sections -----------------------------------------------------------------


def _render_project_picker(container: Container, principal: UserPrincipal) -> None:
    st.subheader("Projects", anchor=False)

    try:
        summaries = container.projects.list_projects(principal)
    except AppError as exc:
        st.error(str(exc))
        summaries = []

    if summaries:
        labels = {
            s.project_id: f"{s.name} · {s.task_count} tasks · {s.updated_at:%d %b %H:%M}"
            if s.updated_at
            else s.name
            for s in summaries
        }
        selected_id = st.selectbox(
            "Saved projects",
            options=list(labels),
            format_func=lambda pid: labels[pid],
            key="project_picker",
        )
        open_col, delete_col = st.columns(2)
        if open_col.button("Open", width="stretch"):
            _open_project(container, selected_id, principal)
        if delete_col.button("Delete", width="stretch"):
            st.session_state["confirm_delete_id"] = selected_id

        if st.session_state.get("confirm_delete_id") == selected_id:
            st.warning(f"Delete **{labels[selected_id].split(' · ')[0]}**?")
            yes, no = st.columns(2)
            if yes.button("Yes, delete", type="primary", width="stretch"):
                _delete_project(container, selected_id, principal)
            if no.button("Cancel", width="stretch"):
                st.session_state.pop("confirm_delete_id", None)
                st.rerun()
    else:
        st.caption("No saved projects yet.")

    with st.expander("Start something new"):
        if st.button("Blank project", width="stretch"):
            session.set_project(container.projects.blank_project(principal), dirty=False)
            session.reset_chat()
            st.rerun()

        templates = container.projects.available_templates()
        template_key = st.selectbox(
            "From template",
            options=[t.key for t in templates],
            format_func=lambda key: next(t.name for t in templates if t.key == key),
            key="template_picker",
        )
        st.caption(next(t.description for t in templates if t.key == template_key))
        if st.button("Load template", width="stretch"):
            session.set_project(
                container.projects.project_from_template(template_key, principal)
            )
            session.reset_chat()
            st.rerun()


def _render_persistence(
    container: Container, project: Project, principal: UserPrincipal, role: ProjectRole
) -> None:
    st.subheader("Save", anchor=False)

    if not role.can_edit:
        st.info("You have read-only access to this project.")
        return

    name = st.text_input("Project name", value=project.name, key="sidebar_project_name")
    if name and name != project.name:
        session.set_project(project.model_copy(update={"name": name}))
        project = session.project or project

    if st.button("Save project", type="primary", width="stretch"):
        _save(container, project, principal)

    if project.version > 0 and st.button("Save as copy", width="stretch"):
        copy = Project(
            name=f"{project.name} (copy)",
            description=project.description,
            view_mode=project.view_mode,
            tasks=project.tasks,
            tenant_id=principal.tenant_id,
            owner_subject=principal.subject,
        )
        _save(container, copy, principal)


def _render_display_options(project: Project) -> DisplayOptions:
    st.subheader("Display", anchor=False)

    current = project.view_mode
    chosen = st.radio(
        "Time scale",
        options=list(_VIEW_LABELS),
        format_func=lambda mode: _VIEW_LABELS[mode],
        index=list(_VIEW_LABELS).index(current),
        horizontal=False,
        key="view_mode_radio",
    )
    if chosen != current:
        session.set_project(project.model_copy(update={"view_mode": chosen}))
        st.rerun()

    return DisplayOptions(
        show_dependencies=st.toggle("Dependency links", value=True, key="opt_deps"),
        show_today=st.toggle("Today marker", value=True, key="opt_today"),
        show_critical_path=st.toggle("Highlight critical path", value=True, key="opt_cpm"),
    )


def _render_exports(container: Container, project: Project, principal: UserPrincipal) -> None:
    st.subheader("Export", anchor=False)
    export_format = st.selectbox("Format", _EXPORT_FORMATS, key="export_format")

    if st.button("Build export", width="stretch", disabled=not project.tasks):
        with st.spinner("Generating…"):
            st.session_state["export_artifact"] = _build_artifact(
                container, project, principal, export_format
            )

    artifact: ExportArtifact | None = st.session_state.get("export_artifact")
    if artifact is not None:
        st.download_button(
            f"Download {artifact.filename}",
            data=artifact.content,
            file_name=artifact.filename,
            mime=artifact.media_type,
            type="primary",
            width="stretch",
        )


def _render_environment_badge(container: Container) -> None:
    settings = container.settings
    st.divider()
    st.caption(
        f"v{settings.app.version} · {settings.app.environment} · "
        f"store: {settings.database.backend} · auth: {settings.auth.provider} · "
        f"AI: {'on' if settings.ai_enabled else 'off'}"
    )


# -- Actions ------------------------------------------------------------------


def _open_project(container: Container, project_id: str, principal: UserPrincipal) -> None:
    try:
        session.set_project(
            container.projects.load_project(project_id, principal), dirty=False
        )
    except AppError as exc:
        st.error(str(exc))
        return
    session.reset_chat()
    st.session_state.pop("export_artifact", None)
    session.queue_toast("Project loaded", "📂")
    st.rerun()


def _delete_project(container: Container, project_id: str, principal: UserPrincipal) -> None:
    try:
        container.projects.delete_project(project_id, principal)
    except AppError as exc:
        st.error(str(exc))
        return
    st.session_state.pop("confirm_delete_id", None)
    current = session.project
    if current is not None and current.project_id == project_id:
        session.set_project(container.projects.blank_project(principal), dirty=False)
    session.queue_toast("Project deleted", "🗑️")
    st.rerun()


def _save(container: Container, project: Project, principal: UserPrincipal) -> None:
    try:
        saved = container.projects.save_project(
            project, principal, expected_version=project.version or None
        )
    except ConcurrencyError as exc:
        st.error(str(exc))
        return
    except AppError as exc:
        st.error(str(exc))
        return
    session.set_project(saved, dirty=False)
    session.queue_toast(f"Saved · version {saved.version}", "💾")
    st.rerun()


def _build_artifact(
    container: Container, project: Project, principal: UserPrincipal, export_format: str
) -> ExportArtifact | None:
    exports = container.exports
    try:
        if export_format.startswith("PowerPoint"):
            artifact = exports.to_pptx(project)
        elif export_format.startswith("Excel"):
            artifact = exports.to_xlsx(project)
        elif export_format.startswith("CSV"):
            artifact = exports.to_csv(project)
        else:
            artifact = exports.to_json(project)
    except AppError as exc:
        st.error(str(exc))
        return None
    except Exception:  # noqa: BLE001 - surface a safe message, log the detail
        st.error("The export could not be generated. Please try again.")
        return None
    container.projects.record_export(project, principal, export_format)
    return artifact
