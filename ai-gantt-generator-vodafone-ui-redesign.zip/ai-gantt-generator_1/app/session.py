"""Typed wrapper around ``st.session_state``.

Keeps magic string keys in one place and gives the views an explicit, readable
contract for per-user state.
"""

from __future__ import annotations

from typing import Any

import streamlit as st
from backend.domain.models import Project, UserPrincipal
from backend.services.ai_service import ChatMessage

_PRINCIPAL = "principal"
_PROJECT = "project"
_CHAT = "chat_messages"
_FLOW = "oidc_flow"
_DIRTY = "unsaved_changes"
_TOAST = "pending_toast"


class Session:
    """Session-scoped state accessor."""

    # -- Identity ----------------------------------------------------------

    @property
    def principal(self) -> UserPrincipal | None:
        return st.session_state.get(_PRINCIPAL)

    @principal.setter
    def principal(self, value: UserPrincipal | None) -> None:
        st.session_state[_PRINCIPAL] = value

    @property
    def oidc_flow(self) -> dict[str, Any]:
        return st.session_state.get(_FLOW, {})

    @oidc_flow.setter
    def oidc_flow(self, value: dict[str, Any]) -> None:
        st.session_state[_FLOW] = value

    # -- Working project ---------------------------------------------------

    @property
    def project(self) -> Project | None:
        return st.session_state.get(_PROJECT)

    @project.setter
    def project(self, value: Project | None) -> None:
        st.session_state[_PROJECT] = value

    @property
    def dirty(self) -> bool:
        return bool(st.session_state.get(_DIRTY, False))

    @dirty.setter
    def dirty(self, value: bool) -> None:
        st.session_state[_DIRTY] = value

    def set_project(self, project: Project, *, dirty: bool = True) -> None:
        self.project = project
        self.dirty = dirty

    # -- Conversation ------------------------------------------------------

    @property
    def chat(self) -> list[ChatMessage]:
        return st.session_state.setdefault(_CHAT, [])

    def append_chat(self, message: ChatMessage) -> None:
        self.chat.append(message)

    def reset_chat(self) -> None:
        st.session_state[_CHAT] = []

    # -- One-shot notifications -------------------------------------------

    def queue_toast(self, message: str, icon: str = "") -> None:
        st.session_state[_TOAST] = (message, icon)

    def flush_toast(self) -> None:
        pending = st.session_state.pop(_TOAST, None)
        if pending:
            message, icon = pending
            st.toast(message, icon=icon or None)

    def sign_out(self) -> None:
        for key in (_PRINCIPAL, _PROJECT, _CHAT, _FLOW, _DIRTY, _TOAST):
            st.session_state.pop(key, None)


session = Session()
