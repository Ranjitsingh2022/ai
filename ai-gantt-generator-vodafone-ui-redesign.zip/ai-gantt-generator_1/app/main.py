"""Application entry point for the Vodafone-style AI Gantt dashboard.

The redesign is presentation-only: domain services, repositories, authentication,
LLM integration and export workflows remain unchanged.
"""
from __future__ import annotations

from pathlib import Path

import streamlit as st
from backend.container import Container
from backend.domain.models import Project, ProjectRole, UserPrincipal
from backend.errors import AppError, ConcurrencyError

from app import theme
from app.auth_gate import render_identity_panel, require_principal
from app.bootstrap import get_container
from app.session import session
from app.views import (
    chat_panel, gantt_view, header, history_view, insights_view,
    project_sidebar, task_editor,
)

_LOGO = Path(__file__).resolve().parents[1] / "assets" / "logo.png"
_NAV = ("Timeline", "Tasks", "Insights", "History")


def main() -> None:
    st.set_page_config(
        page_title="AI Gantt Generator",
        page_icon=str(_LOGO) if _LOGO.exists() else "📊",
        layout="wide",
        initial_sidebar_state="expanded",
        menu_items={"about": "AI Gantt Generator — enterprise project timeline planning."},
    )
    theme.inject()
    container = _resolve_container()
    _render_brand(container)

    principal = require_principal()
    render_identity_panel()
    project = _current_project(container, principal)
    role = container.projects.role_for(project, principal)

    options = project_sidebar.render(project, principal, role)
    project = session.project or project
    role = container.projects.role_for(project, principal)
    stats = container.projects.stats(project)
    issues = container.projects.validate(project)

    _render_toolbar(container, project, principal, role)
    header.render(project, stats, role)

    page = st.session_state.get("dashboard_page", "Timeline")
    if page == "Timeline":
        gantt_view.render(project, stats, options)
        chat_panel.render(project, principal, role)
    elif page == "Tasks":
        task_editor.render(project, editable=role.can_edit)
    elif page == "Insights":
        insights_view.render(project, issues)
    else:
        history_view.render(project, principal, role)

    session.flush_toast()


def _resolve_container() -> Container:
    try:
        return get_container()
    except AppError as exc:
        st.error(str(exc))
        st.stop()
    except Exception:  # noqa: BLE001
        st.error("The application failed to start. Check the server logs for details.")
        st.stop()


def _render_brand(container: Container) -> None:
    with st.sidebar:
        if _LOGO.exists():
            st.image(str(_LOGO), width=142)
        st.markdown(
            f'<div class="brand-title">{container.settings.app.name}</div>'
            '<div class="brand-subtitle">Enterprise project timeline planning with AI assistance</div>',
            unsafe_allow_html=True,
        )
        st.markdown('<div class="sidebar-section-label">WORKSPACE</div>', unsafe_allow_html=True)
        current = st.session_state.get("dashboard_page", "Timeline")
        selected = st.radio(
            "Navigation", _NAV, index=_NAV.index(current) if current in _NAV else 0,
            label_visibility="collapsed", key="dashboard_navigation",
        )
        st.session_state["dashboard_page"] = selected
        st.markdown('<div class="sidebar-section-label">PROJECT TOOLS</div>', unsafe_allow_html=True)


def _render_toolbar(
    container: Container, project: Project, principal: UserPrincipal, role: ProjectRole
) -> None:
    title_col, new_col, save_col, copy_col, export_col = st.columns([4.4, 1.05, 0.85, 1.1, 0.85])
    with title_col:
        st.markdown(
            '<div class="toolbar-eyebrow">PROJECT WORKSPACE</div>'
            f'<div class="toolbar-project">{_escape(project.name)}</div>',
            unsafe_allow_html=True,
        )
    if new_col.button("＋ New project", use_container_width=True):
        session.set_project(container.projects.blank_project(principal), dirty=False)
        session.reset_chat()
        st.rerun()
    if save_col.button("Save", type="primary", use_container_width=True, disabled=not role.can_edit):
        try:
            saved = container.projects.save_project(
                project, principal, expected_version=project.version or None
            )
            session.set_project(saved, dirty=False)
            session.queue_toast(f"Saved · version {saved.version}", "💾")
            st.rerun()
        except ConcurrencyError as exc:
            st.error(str(exc))
        except AppError as exc:
            st.error(str(exc))
    if copy_col.button("Save as copy", use_container_width=True, disabled=not role.can_edit or project.version == 0):
        copy = Project(
            name=f"{project.name} (copy)", description=project.description,
            view_mode=project.view_mode, tasks=project.tasks,
            tenant_id=principal.tenant_id, owner_subject=principal.subject,
        )
        try:
            saved = container.projects.save_project(copy, principal)
            session.set_project(saved, dirty=False)
            session.queue_toast("Project copy saved", "📄")
            st.rerun()
        except AppError as exc:
            st.error(str(exc))
    if export_col.button("Export", use_container_width=True):
        st.session_state["dashboard_page"] = "History"
        st.info("Use the Export controls in the sidebar to choose PowerPoint, Excel, CSV or JSON.")
        st.rerun()


def _current_project(container: Container, principal: UserPrincipal) -> Project:
    project = session.project
    if project is None:
        project = container.projects.blank_project(principal)
        session.set_project(project, dirty=False)
    return project


def _escape(value: str) -> str:
    return (value.replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


if __name__ == "__main__":
    main()
