"""Domain model invariants."""

from __future__ import annotations

from datetime import date

import pytest
from backend.domain.models import DEFAULT_TASK_COLOR, Project, Task
from pydantic import ValidationError


def _task(**overrides: object) -> Task:
    base = {
        "ref": "T1",
        "name": "Design",
        "start_date": date(2026, 1, 5),
        "end_date": date(2026, 1, 9),
    }
    return Task(**{**base, **overrides})  # type: ignore[arg-type]


def test_milestone_collapses_end_date() -> None:
    task = _task(is_milestone=True, end_date=date(2026, 2, 1))
    assert task.end_date == task.start_date
    assert task.duration_days == 0


def test_end_before_start_is_repaired() -> None:
    assert _task(end_date=date(2026, 1, 1)).end_date == date(2026, 1, 5)


def test_duration_is_inclusive() -> None:
    assert _task().duration_days == 5


@pytest.mark.parametrize(
    ("raw", "expected"),
    [
        ("T1, T2", ("T1", "T2")),
        ("t3;t4 t5", ("T3", "T4", "T5")),
        (["T1", "T1", "bogus"], ("T1",)),
        (None, ()),
    ],
)
def test_dependency_coercion(raw: object, expected: tuple[str, ...]) -> None:
    # ref T9 avoids the self-dependency rule stripping its own id.
    assert _task(ref="T9", dependencies=raw).dependencies == expected


def test_self_dependency_is_removed() -> None:
    assert _task(dependencies=["T1", "T2"]).dependencies == ("T2",)


def test_invalid_colour_falls_back_to_brand() -> None:
    assert _task(color="rgb(1,2,3)").color == DEFAULT_TASK_COLOR
    assert _task(color="#abc").color == "#ABC"


def test_progress_is_bounded() -> None:
    with pytest.raises(ValidationError):
        _task(progress=140)


def test_project_drops_dangling_dependencies() -> None:
    project = Project(tasks=(_task(ref="T1", dependencies=["T9"]),))
    assert project.tasks[0].dependencies == ()


def test_next_ref_skips_used_numbers() -> None:
    project = Project(tasks=(_task(ref="T1"), _task(ref="T7")))
    assert project.next_ref() == "T8"
