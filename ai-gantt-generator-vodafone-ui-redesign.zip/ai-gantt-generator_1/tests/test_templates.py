"""Built-in templates must produce internally consistent schedules."""

from __future__ import annotations

from backend.domain.scheduling import detect_cycles, validate_schedule
from backend.domain.templates import TEMPLATES


def test_templates_have_no_cycles_or_overlaps() -> None:
    for template in TEMPLATES:
        project = template.to_project()
        assert detect_cycles(project.tasks) == (), template.key
        codes = {issue.code for issue in validate_schedule(project)}
        assert "predecessor_overlap" not in codes, template.key
        assert "dependency_cycle" not in codes, template.key


def test_templates_have_unique_refs_and_owners() -> None:
    for template in TEMPLATES:
        project = template.to_project()
        refs = [task.ref for task in project.tasks]
        assert len(refs) == len(set(refs)), template.key
        assert all(task.owner for task in project.tasks), template.key
