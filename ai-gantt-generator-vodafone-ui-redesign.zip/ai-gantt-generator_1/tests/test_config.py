"""Configuration loading, secret references and fail-fast validation."""

from __future__ import annotations

from pathlib import Path

import pytest

from backend.config import (
    CONFIG_FILE_ENV,
    is_secret_ref,
    load_settings,
    resolve_ref,
)
from backend.errors import ConfigurationError

SHIPPED_CONFIG = Path(__file__).resolve().parents[1] / "config" / "app.toml"


def _write(tmp_path: Path, body: str) -> Path:
    path = tmp_path / "app.toml"
    path.write_text(body, encoding="utf-8")
    return path


def test_shipped_config_is_valid_and_safe_by_default() -> None:
    settings = load_settings(SHIPPED_CONFIG)
    assert settings.llm.enabled is False
    assert settings.auth.provider == "local"
    assert settings.is_production is False


def test_empty_file_yields_defaults(tmp_path: Path) -> None:
    settings = load_settings(_write(tmp_path, ""))
    assert settings.llm.auth.method == "adc"
    assert settings.database.backend == "sqlite"
    assert settings.database.sqlite_path.is_absolute()


def test_unknown_key_is_rejected(tmp_path: Path) -> None:
    with pytest.raises(ConfigurationError, match=r"llm\.modle"):
        load_settings(_write(tmp_path, '[llm]\nmodle = "typo"\n'))


def test_invalid_toml_is_reported(tmp_path: Path) -> None:
    with pytest.raises(ConfigurationError, match="not valid TOML"):
        load_settings(_write(tmp_path, "[llm\n"))


def test_missing_explicit_file_fails(tmp_path: Path) -> None:
    with pytest.raises(ConfigurationError, match="not found"):
        load_settings(tmp_path / "nope.toml")


def test_env_var_selects_config_file(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    path = _write(tmp_path, '[app]\nname = "From Env Path"\n')
    monkeypatch.setenv(CONFIG_FILE_ENV, str(path))
    assert load_settings().app.name == "From Env Path"


# -- Secret references ---------------------------------------------------------


def test_resolve_ref_reads_environment(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("GANTT_TEST_SECRET", "s3cret")
    assert resolve_ref("env:GANTT_TEST_SECRET") == "s3cret"


def test_resolve_ref_reads_file(tmp_path: Path) -> None:
    secret = tmp_path / "secret.txt"
    secret.write_text("from-file\n", encoding="utf-8")
    assert resolve_ref(f"file:{secret}") == "from-file"


def test_resolve_ref_passes_literals_through() -> None:
    assert resolve_ref("plain-value") == "plain-value"
    assert not is_secret_ref("plain-value")


def test_resolve_ref_fails_when_unset(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("GANTT_MISSING", raising=False)
    with pytest.raises(ConfigurationError, match="GANTT_MISSING"):
        resolve_ref("env:GANTT_MISSING")


# -- LLM wiring ----------------------------------------------------------------


def test_service_account_method_requires_a_file(tmp_path: Path) -> None:
    body = '[llm]\nenabled = true\n[llm.auth]\nmethod = "service_account_file"\n'
    with pytest.raises(ConfigurationError, match="service_account_file"):
        load_settings(_write(tmp_path, body))


def test_impersonation_requires_a_service_account(tmp_path: Path) -> None:
    body = '[llm]\nenabled = true\n[llm.auth]\nmethod = "impersonation"\n'
    with pytest.raises(ConfigurationError, match=r"llm\.auth\.service_account"):
        load_settings(_write(tmp_path, body))


def test_id_token_requires_audience_or_gateway_url_and_project(tmp_path: Path) -> None:
    body = '[llm]\nenabled = true\n[llm.auth]\nmethod = "id_token"\n'
    with pytest.raises(ConfigurationError) as caught:
        load_settings(_write(tmp_path, body))
    assert "audience" in str(caught.value)
    assert "llm.project_id" in str(caught.value)


def test_id_token_accepts_a_gateway_url_in_place_of_an_audience(tmp_path: Path) -> None:
    body = (
        '[llm]\nenabled = true\nproject_id = "p"\n'
        '[llm.gateway]\nurl = "https://proxy.example.com/google-llm"\n'
        '[llm.auth]\nmethod = "id_token"\nservice_account = "sa@p.iam.gserviceaccount.com"\n'
    )
    settings = load_settings(_write(tmp_path, body))
    assert settings.llm.auth.service_account == "sa@p.iam.gserviceaccount.com"


def test_gateway_token_requires_token_and_project(tmp_path: Path) -> None:
    body = '[llm]\nenabled = true\n[llm.auth]\nmethod = "gateway_token"\n'
    with pytest.raises(ConfigurationError) as caught:
        load_settings(_write(tmp_path, body))
    assert "llm.auth.token" in str(caught.value)
    assert "llm.project_id" in str(caught.value)


def test_gateway_must_use_https(tmp_path: Path) -> None:
    body = '[llm]\nenabled = true\n[llm.gateway]\nurl = "http://gateway.corp.example.com"\n'
    with pytest.raises(ConfigurationError, match="https"):
        load_settings(_write(tmp_path, body))


def test_plain_http_is_allowed_for_localhost_outside_production(tmp_path: Path) -> None:
    body = '[llm]\nenabled = true\n[llm.gateway]\nurl = "http://localhost:4000"\n'
    assert load_settings(_write(tmp_path, body)).llm.gateway.url == "http://localhost:4000"


def test_forward_proxy_scheme_is_checked(tmp_path: Path) -> None:
    body = '[llm]\nenabled = true\n[llm.network]\nforward_proxy = "ftp://proxy"\n'
    with pytest.raises(ConfigurationError, match="forward_proxy"):
        load_settings(_write(tmp_path, body))


def test_disabled_llm_skips_llm_validation(tmp_path: Path) -> None:
    body = '[llm]\nenabled = false\n[llm.auth]\nmethod = "gateway_token"\n'
    assert load_settings(_write(tmp_path, body)).ai_enabled is False


# -- Production guards ---------------------------------------------------------


def test_production_rejects_local_sign_in(tmp_path: Path) -> None:
    with pytest.raises(ConfigurationError, match="local"):
        load_settings(_write(tmp_path, '[app]\nenvironment = "production"\n'))


def test_production_rejects_literal_secrets_without_echoing_them(tmp_path: Path) -> None:
    body = (
        '[app]\nenvironment = "production"\n'
        '[auth]\nprovider = "entra_id"\n'
        '[auth.entra]\ntenant_id = "t"\nclient_id = "c"\n'
        'client_secret = "super-secret-value"\nredirect_uri = "https://app.example.com/"\n'
    )
    with pytest.raises(ConfigurationError) as caught:
        load_settings(_write(tmp_path, body))
    assert "env:" in str(caught.value)
    assert "super-secret-value" not in str(caught.value)


def test_production_accepts_secret_references(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("GANTT_ENTRA_SECRET", "resolved")
    body = (
        '[app]\nenvironment = "production"\n'
        '[auth]\nprovider = "entra_id"\n'
        '[auth.entra]\ntenant_id = "t"\nclient_id = "c"\n'
        'client_secret = "env:GANTT_ENTRA_SECRET"\nredirect_uri = "https://app.example.com/"\n'
    )
    settings = load_settings(_write(tmp_path, body))
    assert settings.is_production
    assert settings.auth.provider == "entra_id"


def test_unresolvable_secret_reference_fails_at_startup(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("GANTT_UNSET_TOKEN", raising=False)
    body = (
        '[llm]\nenabled = true\nproject_id = "p"\n'
        '[llm.auth]\nmethod = "gateway_token"\ntoken = "env:GANTT_UNSET_TOKEN"\n'
    )
    with pytest.raises(ConfigurationError, match="GANTT_UNSET_TOKEN"):
        load_settings(_write(tmp_path, body))
