"""Repository persistence, tenancy isolation and optimistic concurrency."""

from __future__ import annotations

import pytest
from backend.domain.models import Project, ProjectRole, UserPrincipal
from backend.errors import ConcurrencyError
from backend.repositories.sqlite_repository import SqliteProjectRepository


def test_round_trip_preserves_tasks(
    repository: SqliteProjectRepository, principal: UserPrincipal, sample_project: Project
) -> None:
    repository.upsert_user(principal)
    saved = repository.save_project(sample_project, principal, expected_version=None)
    assert saved.version == 1

    loaded = repository.get_project(saved.project_id, principal)
    assert loaded is not None
    assert [t.ref for t in loaded.tasks] == ["T1", "T2", "T3", "T4"]
    assert loaded.task_by_ref("T4") is not None
    assert loaded.task_by_ref("T4").is_milestone is True
    assert loaded.task_by_ref("T2").dependencies == ("T1",)


def test_version_increments_and_conflicts_are_detected(
    repository: SqliteProjectRepository, principal: UserPrincipal, sample_project: Project
) -> None:
    saved = repository.save_project(sample_project, principal, expected_version=None)
    again = repository.save_project(saved, principal, expected_version=saved.version)
    assert again.version == 2

    with pytest.raises(ConcurrencyError):
        repository.save_project(saved, principal, expected_version=1)


def test_other_tenant_cannot_read_project(
    repository: SqliteProjectRepository,
    principal: UserPrincipal,
    other_principal: UserPrincipal,
    sample_project: Project,
) -> None:
    saved = repository.save_project(sample_project, principal, expected_version=None)
    assert repository.get_project(saved.project_id, other_principal) is None
    assert repository.get_role(saved.project_id, other_principal) is None
    assert repository.list_projects(other_principal) == []


def test_owner_role_and_listing(
    repository: SqliteProjectRepository, principal: UserPrincipal, sample_project: Project
) -> None:
    repository.save_project(sample_project, principal, expected_version=None)
    summaries = repository.list_projects(principal)
    assert len(summaries) == 1
    assert summaries[0].task_count == 4
    assert summaries[0].role is ProjectRole.OWNER


def test_soft_delete_hides_project(
    repository: SqliteProjectRepository, principal: UserPrincipal, sample_project: Project
) -> None:
    saved = repository.save_project(sample_project, principal, expected_version=None)
    repository.soft_delete_project(saved.project_id, principal)
    assert repository.get_project(saved.project_id, principal) is None
    assert repository.list_projects(principal) == []


def test_revisions_are_capped_and_restorable(
    repository: SqliteProjectRepository, principal: UserPrincipal, sample_project: Project
) -> None:
    project = repository.save_project(sample_project, principal, expected_version=None)
    for index in range(7):
        project = repository.save_project(
            project.model_copy(update={"name": f"Rev {index}"}),
            principal,
            expected_version=project.version,
        )

    revisions = repository.list_revisions(project.project_id, principal)
    assert len(revisions) == 5  # revision_limit fixture value
    newest_version = revisions[0][0]
    snapshot = repository.get_revision(project.project_id, newest_version, principal)
    assert snapshot is not None
    assert snapshot.name == "Rev 6"
