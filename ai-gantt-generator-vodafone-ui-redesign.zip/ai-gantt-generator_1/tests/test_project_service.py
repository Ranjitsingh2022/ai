"""Application service orchestration and guardrails."""

from __future__ import annotations

from datetime import timedelta

import pytest
from backend.domain.models import Project, ProjectRole, UserPrincipal
from backend.errors import NotFoundError, ValidationError
from backend.services.project_service import ProjectService

from tests.conftest import TODAY, make_task


def test_blank_project_is_owned_by_caller(
    service: ProjectService, principal: UserPrincipal
) -> None:
    project = service.blank_project(principal)
    assert project.owner_subject == principal.subject
    assert project.version == 0
    assert service.role_for(project, principal) is ProjectRole.OWNER


def test_templates_produce_valid_projects(service: ProjectService, principal: UserPrincipal) -> None:
    for template in service.available_templates():
        project = service.project_from_template(template.key, principal)
        assert project.tasks
        known = {t.ref for t in project.tasks}
        assert all(dep in known for t in project.tasks for dep in t.dependencies)


def test_unknown_template_raises(service: ProjectService, principal: UserPrincipal) -> None:
    with pytest.raises(NotFoundError):
        service.project_from_template("does-not-exist", principal)


def test_add_task_allocates_next_ref(
    service: ProjectService, sample_project: Project
) -> None:
    updated = service.add_task(sample_project)
    assert updated.tasks[-1].ref == "T5"
    assert len(updated.tasks) == len(sample_project.tasks) + 1


def test_task_limit_is_enforced(service: ProjectService, sample_project: Project) -> None:
    many = [make_task(f"T{i}", i, 1) for i in range(1, 60)]
    with pytest.raises(ValidationError):
        service.replace_tasks(sample_project, many)


def test_shift_task_cascades(service: ProjectService, sample_project: Project) -> None:
    shifted = service.shift_task(sample_project, "T1", 5)
    assert shifted.task_by_ref("T1").start_date == TODAY + timedelta(days=5)
    assert shifted.task_by_ref("T4").start_date == TODAY + timedelta(days=25)


def test_remove_task_cleans_dependencies(
    service: ProjectService, sample_project: Project
) -> None:
    updated = service.remove_task(sample_project, "T1")
    assert updated.task_by_ref("T1") is None
    assert updated.task_by_ref("T2").dependencies == ()


def test_save_then_load_round_trip(
    service: ProjectService, principal: UserPrincipal, sample_project: Project
) -> None:
    saved = service.save_project(sample_project, principal)
    loaded = service.load_project(saved.project_id, principal)
    assert loaded.name == sample_project.name
    assert loaded.version == 1
    assert service.role_for(loaded, principal) is ProjectRole.OWNER


def test_load_missing_project_raises(
    service: ProjectService, principal: UserPrincipal
) -> None:
    with pytest.raises(NotFoundError):
        service.load_project("missing", principal)


def test_restore_revision(
    service: ProjectService, principal: UserPrincipal, sample_project: Project
) -> None:
    saved = service.save_project(sample_project, principal)
    trimmed = service.save_project(
        saved.with_tasks(saved.tasks[:1]), principal, expected_version=saved.version
    )
    assert len(trimmed.tasks) == 1

    restored = service.restore_revision(saved.project_id, 1, principal)
    assert len(restored.tasks) == 4
    assert restored.version == 3
