# AI Project Gantt Generator

Enterprise project-timeline planning with an AI assistant, an interactive Gantt
chart and one-click PowerPoint / Excel / CSV / JSON export.

Rebuilt as a **pure Python** application: Streamlit frontend, framework-agnostic
Python backend, relational persistence. **No Node.js, no npm, no bundler.**

---

## 1. Architecture

```
┌──────────────────────────────────────────────────────────────┐
│  app/            Presentation (Streamlit only)               │
│    main.py         entry point & page composition            │
│    auth_gate.py    sign-in gate (local dev / Entra ID)       │
│    session.py      typed wrapper over st.session_state       │
│    views/          header, sidebar, task grid, chart, chat   │
│    components/     Plotly Gantt figure builder               │
└───────────────────────────┬──────────────────────────────────┘
                            │  depends on (one direction only)
┌───────────────────────────▼──────────────────────────────────┐
│  backend/        Business logic (no Streamlit imports)       │
│    container.py    composition root / dependency injection   │
│    config.py       typed settings from config/app.toml       │
│    domain/         models, scheduling algorithms, templates  │
│    services/       project, AI planning, export use cases    │
│    repositories/   storage contracts + SQLite & BigQuery     │
│    auth/           AuthProvider contract + implementations   │
│    db/db.sql       relational schema (SQLite → BigQuery)     │
└──────────────────────────────────────────────────────────────┘
```

Key rules enforced by this layout:

| Rule | Why |
| --- | --- |
| `backend/` never imports `streamlit` | The same logic can be exposed as a REST API, CLI or batch job. |
| Services depend on `Protocol`s, not classes | Storage and identity are swappable at the composition root. |
| All external input is validated by Pydantic | AI output, grid edits and database rows are untrusted. |
| Every mutation is audited | Compliance and incident forensics. |

---

## 2. Quick start

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt

streamlit run app/main.py
```

Open <http://localhost:8501>. The SQLite database is created automatically at
`data/gantt.db`.

Out of the box the AI assistant is **disabled** (`llm.enabled = false` in
[config/app.toml](config/app.toml)); everything else (editing, charting, export,
history) works. To enable it, see [section 4](#4-configuration).

---

## 3. Features

**Planning**
- Conversational AI planner (Gemini on Vertex AI, function calling) that drafts
  and amends dependency-aware timelines.
- Three built-in starter templates.
- Spreadsheet-style task grid with inline date, owner, progress and dependency
  editing.

**Scheduling intelligence**
- Dependency cycle detection.
- Cascade shifting — moving a task moves everything downstream.
- "Align dates" enforces finish-to-start constraints across the whole plan.
- Critical path (simplified CPM) highlighted on the chart.
- Quality checks: overdue work, predecessor overlaps, unassigned tasks.

**Collaboration & governance**
- Projects persisted per tenant with owner / editor / viewer roles.
- Optimistic concurrency — concurrent edits cannot silently overwrite.
- Automatic revision history with point-in-time restore.
- Soft delete; append-only audit log.

**Output**
- Server-side PowerPoint deck (paginated, branded, milestones and progress).
- Excel workbook, CSV and round-trippable JSON.
- PNG of the chart straight from the Plotly toolbar.

---

## 4. Configuration

**One file configures everything:** [config/app.toml](config/app.toml). It is
commented section by section. Use another copy by setting `APP_CONFIG_FILE`
(for example a file mounted from Secret Manager).

| Section | Controls |
| --- | --- |
| `[app]` | Name, environment, logging. |
| `[llm]` | Vertex AI project, region, model, timeouts, retries, rate limit. |
| `[llm.gateway]` | Optional enterprise LLM proxy: API endpoint URL, API version, extra headers. |
| `[llm.network]` | Outbound forward proxy and corporate CA bundle. |
| `[llm.auth]` | How the app authenticates: method, service account, token audience. |
| `[database]` | `sqlite` today, `bigquery` later. |
| `[auth]` | User sign-in: `local` (dev) or `entra_id`, plus Entra settings. |
| `[limits]` | Task / project / revision guardrails. |

**Secrets are never typed into the file.** Use a reference instead:
`"env:NAME"` reads an environment variable, `"file:/path"` reads a mounted file.
In staging and production, literal secrets and unresolvable references are
rejected at start-up, and unknown keys are rejected everywhere.

### LLM: Vertex AI only

API keys are not supported. Any `GOOGLE_API_KEY` / `GEMINI_API_KEY` in the
environment is ignored (and logged as a warning).

```toml
[llm]
enabled = true
project_id = "my-gcp-project"
location = "europe-west4"

[llm.auth]
method = "adc"
```

| `llm.auth.method` | Use when |
| --- | --- |
| `adc` | Workload Identity on Cloud Run/GKE, or `gcloud auth application-default login` locally. Calls Vertex AI directly. |
| `id_token` | **Your Cloud Run LLM proxy.** Sends an OIDC ID token whose audience is the proxy. |
| `service_account_file` | You must use a JSON key file. |
| `impersonation` | Access token of `service_account`, impersonated from the runtime identity. |
| `gateway_token` | Your proxy issues its own bearer token (`token = "env:..."`). |
| `none` | The proxy authenticates through `[llm.gateway] headers` only. |

### Using the Cloud Run LLM proxy

The project, region, proxy endpoint and service account are all plain settings,
so moving between proxies or environments is a config change:

```toml
[llm]
enabled = true
project_id = "my-lab-project"          # project the proxy bills to
location = "europe-west1"

[llm.gateway]
url = "https://proxy-service-123456789.europe-west1.run.app/google-llm"
api_version = "v1beta1"

[llm.auth]
method = "id_token"
service_account = "my-lab-sa@my-lab-project.iam.gserviceaccount.com"
audience = "https://proxy-service-123456789.europe-west1.run.app"   # blank = origin of gateway.url
```

This is equivalent to creating the client with
`genai.Client(vertexai=True, project=..., location=..., credentials=<ID token>,
http_options=HttpOptions(base_url=<gateway.url>, api_version=...))`.

Which identity mints the ID token (first match wins):

1. `service_account_file` - a service-account key file.
2. `service_account` - the runtime identity impersonates that service account. It
   needs `roles/iam.serviceAccountTokenCreator` on it, and the service account
   needs `roles/run.invoker` on the proxy.
3. Neither set - the runtime identity itself (the Cloud Run metadata server, or
   `GOOGLE_APPLICATION_CREDENTIALS`). A plain `gcloud auth application-default
   login` user credential **cannot** mint ID tokens, so on a workstation set
   `service_account`.

**Other proxy options**

```toml
[llm.network]
forward_proxy = "http://proxy.corp.example.com:8080"   # outbound HTTP(S) proxy
ca_bundle = "/etc/ssl/corp-ca.pem"                     # corporate CA chain

[llm.gateway]
headers = { "X-Team-Id" = "planning" }                 # values may be env:/file: refs
```

The proxy must expose the Vertex AI path layout
(`{url}/{api_version}/projects/{project}/locations/{location}/...`). Leave
`url` blank to call Vertex AI directly. If `url` is set to the proxy origin
only (for example `https://proxy-123.europe-west1.run.app`), the app
automatically appends `/google-llm`.

---

## 5. Data model

The schema lives in [backend/db/db.sql](backend/db/db.sql) and is applied
automatically at start-up (idempotent `CREATE TABLE IF NOT EXISTS`).

| Table | Purpose |
| --- | --- |
| `users` | Identity projection, refreshed on sign-in. |
| `projects` | Aggregate root; soft delete + optimistic `version`. |
| `project_members` | Per-project RBAC (`owner` / `editor` / `viewer`). |
| `tasks` | Schedule rows, unique per `(project_id, task_ref)`. |
| `task_dependencies` | Finish-to-start edges. |
| `project_revisions` | JSON snapshot per save → history & restore. |
| `audit_log` | Append-only security trail. |
| `v_project_summary` | Listing projection used by the sidebar. |

### Migrating to BigQuery

The migration notes at the top of `db.sql` map every SQLite type and index to
its BigQuery equivalent (partitioning, clustering, `MERGE` write strategy).
Implement `BigQueryProjectRepository` in
[backend/repositories/bigquery_repository.py](backend/repositories/bigquery_repository.py)
and set `database.backend = "bigquery"` in `config/app.toml`. No service or view
changes are required — both implementations satisfy the same
`ProjectRepository` protocol.

---

## 6. Authentication

| Provider | When | Behaviour |
| --- | --- | --- |
| `local` | Development only | Deterministic dev principal; refuses to start when `app.environment` is staging/production. |
| `entra_id` | Production | OIDC authorization-code flow with PKCE via MSAL. |

Entra ID enablement steps are documented in
[backend/auth/entra_provider.py](backend/auth/entra_provider.py). In short:
register the app, add the redirect URI, grant `User.Read`, store the client
secret in Secret Manager, then set `provider = "entra_id"` under `[auth]` and
fill `[auth.entra]` (with `client_secret = "env:ENTRA_CLIENT_SECRET"`).

Entra **app roles** map onto `UserPrincipal.roles`, ready to drive
organisation-wide authorisation.

---

## 7. Development

```powershell
pip install -r requirements-dev.txt

python -m pytest              # unit tests
python -m ruff check .        # lint
python -m ruff format .       # format
python -m mypy backend app    # static types
```

Tests cover the domain invariants, scheduling algorithms, repository behaviour
(including tenant isolation and concurrency), AI output hardening and export
generation. No test requires network access or Google credentials.

---

## 8. Deployment

See [GCP_CLOUD_RUN_DEPLOYMENT.md](GCP_CLOUD_RUN_DEPLOYMENT.md).

```powershell
docker build -t ai-gantt-generator:local .
docker run --rm -p 8080:8080 `
  -v ${PWD}/config/app.toml:/etc/gantt/app.toml:ro `
  ai-gantt-generator:local
```

The configuration file is not baked into the image; mount it at
`/etc/gantt/app.toml`.

The image is multi-stage, runs as an unprivileged user (uid 10001) and exposes
Streamlit's `/_stcore/health` endpoint for liveness and readiness probes.

---

## 9. Legacy

The previous Node.js/Express + jQuery implementation is preserved under
`legacy/` for reference. It is excluded from the container image and is no
longer maintained.
