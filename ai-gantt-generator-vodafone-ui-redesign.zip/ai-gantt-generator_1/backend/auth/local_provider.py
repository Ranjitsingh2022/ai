"""Local (non-interactive) auth provider for development and testing.

Refuses to run in staging/production so it can never become a backdoor.
"""

from __future__ import annotations

import hashlib

from backend.auth.base import LoginChallenge
from backend.config import Settings
from backend.domain.models import UserPrincipal
from backend.errors import ConfigurationError


class LocalAuthProvider:
    """Returns a deterministic development principal."""

    name = "local"

    def __init__(self, settings: Settings) -> None:
        if settings.is_production:
            raise ConfigurationError(
                "auth.provider = 'local' is not permitted in staging or production. "
                "Configure auth.provider = 'entra_id'."
            )
        self._local = settings.auth.local

    @property
    def interactive(self) -> bool:
        return False

    def principal(self) -> UserPrincipal:
        email = self._local.user_email
        subject = "local:" + hashlib.sha256(email.encode("utf-8")).hexdigest()[:32]
        return UserPrincipal(
            subject=subject,
            tenant_id=self._local.tenant_id,
            email=email,
            display_name=email.split("@", 1)[0].replace(".", " ").title(),
            roles=("project.editor",),
            auth_provider=self.name,
        )

    def begin_login(self) -> LoginChallenge:  # pragma: no cover - not interactive
        raise ConfigurationError("The local provider does not use an interactive flow.")

    def complete_login(
        self,
        flow: dict[str, object],  # noqa: ARG002 - required by AuthProvider
        query_params: dict[str, str],  # noqa: ARG002 - required by AuthProvider
    ) -> UserPrincipal:
        return self.principal()

    def logout_url(
        self,
        post_logout_redirect_uri: str | None = None,  # noqa: ARG002 - interface parity
    ) -> str | None:
        return None
