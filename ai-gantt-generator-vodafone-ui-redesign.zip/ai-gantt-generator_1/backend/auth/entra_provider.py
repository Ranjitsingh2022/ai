"""Microsoft Entra ID (Azure AD) SSO via OpenID Connect.

Implements the confidential-client authorization-code flow with PKCE using
MSAL. State and the PKCE verifier are held in the server-side flow dict and
must never be exposed to the browser beyond the opaque ``state`` parameter.

Enablement checklist
--------------------
1. Register an application in Entra ID (single or multi tenant).
2. Add a *Web* redirect URI equal to ``ENTRA_REDIRECT_URI``
   (e.g. ``https://gantt.example.com/``).
3. Grant delegated Microsoft Graph permission ``User.Read`` and admin-consent.
4. Create a client secret (or, preferred, a federated workload identity
   credential) and store it in the platform secret manager.
5. Set ``AUTH_PROVIDER=entra_id`` plus the four ``ENTRA_*`` variables.
6. Optionally map Entra app roles / group claims onto
   :attr:`~backend.domain.models.UserPrincipal.roles` in ``_to_principal``.
"""

from __future__ import annotations

from typing import Any, cast

from backend.auth.base import LoginChallenge
from backend.config import Settings, resolve_secret
from backend.domain.models import UserPrincipal
from backend.errors import AuthenticationError, ConfigurationError
from backend.logging_config import get_logger

logger = get_logger(__name__)


class EntraIdAuthProvider:
    """OIDC authorization-code provider backed by MSAL."""

    name = "entra_id"

    def __init__(self, settings: Settings) -> None:
        entra = settings.auth.entra
        if not (
            entra.tenant_id and entra.client_id and entra.client_secret and entra.redirect_uri
        ):
            raise ConfigurationError("Entra ID SSO is not fully configured (auth.entra).")
        if not entra.redirect_uri.startswith("https://") and settings.is_production:
            raise ConfigurationError("auth.entra.redirect_uri must use HTTPS in production.")

        self._entra = entra
        self._authority = f"https://login.microsoftonline.com/{entra.tenant_id}"
        self._client: Any | None = None

    @property
    def interactive(self) -> bool:
        return True

    def _app(self) -> Any:
        if self._client is None:
            try:
                import msal  # imported lazily: optional dependency
            except ImportError as exc:  # pragma: no cover
                raise ConfigurationError(
                    "The 'msal' package is required for Entra ID SSO."
                ) from exc

            self._client = msal.ConfidentialClientApplication(
                client_id=self._entra.client_id,
                authority=self._authority,
                client_credential=resolve_secret(self._entra.client_secret),
            )
        return self._client

    def begin_login(self) -> LoginChallenge:
        flow = cast(
            dict[str, Any],
            self._app().initiate_auth_code_flow(
                scopes=list(self._entra.scopes),
                redirect_uri=self._entra.redirect_uri,
                prompt="select_account",
            ),
        )
        if "auth_uri" not in flow:  # pragma: no cover - MSAL error path
            raise AuthenticationError("Could not start the sign-in flow.")
        return LoginChallenge(
            authorization_url=str(flow["auth_uri"]),
            state=str(flow.get("state", "")),
            flow=flow,
        )

    def complete_login(
        self, flow: dict[str, object], query_params: dict[str, str]
    ) -> UserPrincipal:
        if not flow:
            raise AuthenticationError("The sign-in session expired. Please try again.")
        if query_params.get("state") != flow.get("state"):
            logger.warning("oidc_state_mismatch")
            raise AuthenticationError("Sign-in could not be verified. Please try again.")

        result = cast(
            dict[str, Any],
            self._app().acquire_token_by_auth_code_flow(flow, dict(query_params)),
        )
        if "error" in result:
            logger.warning("oidc_token_exchange_failed", extra={"error": result.get("error")})
            raise AuthenticationError("Sign-in failed. Please try again.")

        claims = result.get("id_token_claims") or {}
        return self._to_principal(claims)

    def _to_principal(self, claims: dict[str, Any]) -> UserPrincipal:
        subject = claims.get("oid") or claims.get("sub")
        tenant_id = claims.get("tid") or self._entra.tenant_id
        if not subject or not tenant_id:
            raise AuthenticationError("The identity token is missing required claims.")

        roles = tuple(str(r) for r in claims.get("roles", ()) if r)
        return UserPrincipal(
            subject=str(subject),
            tenant_id=str(tenant_id),
            email=str(claims.get("preferred_username") or claims.get("email") or ""),
            display_name=str(claims.get("name") or ""),
            roles=roles,
            auth_provider=self.name,
        )

    def logout_url(self, post_logout_redirect_uri: str | None = None) -> str | None:
        redirect = post_logout_redirect_uri or self._entra.redirect_uri
        return (
            f"{self._authority}/oauth2/v2.0/logout"
            f"?post_logout_redirect_uri={redirect}"
        )
