"""Authentication contract.

Deliberately framework-agnostic: the provider never touches HTTP objects or
Streamlit session state. The frontend passes in the OAuth callback parameters
and stores the returned principal wherever it likes.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, runtime_checkable

from backend.domain.models import UserPrincipal


@dataclass(frozen=True, slots=True)
class LoginChallenge:
    """Everything the frontend needs to start an authorization-code flow."""

    authorization_url: str
    state: str
    flow: dict[str, object]
    """Opaque provider state (PKCE verifier, nonce). Store server-side only."""


@runtime_checkable
class AuthProvider(Protocol):
    """Pluggable identity source."""

    name: str

    @property
    def interactive(self) -> bool:
        """``True`` when the user must be redirected to an external IdP."""

    def begin_login(self) -> LoginChallenge:
        """Create the authorization request."""

    def complete_login(
        self, flow: dict[str, object], query_params: dict[str, str]
    ) -> UserPrincipal:
        """Exchange the callback parameters for a validated principal."""

    def logout_url(self, post_logout_redirect_uri: str | None = None) -> str | None:
        """IdP sign-out URL, or ``None`` when sign-out is local only."""
