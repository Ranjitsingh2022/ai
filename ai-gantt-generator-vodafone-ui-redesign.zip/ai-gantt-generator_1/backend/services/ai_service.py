"""Vertex AI (Gemini) planning assistant.

Responsibilities
----------------
* Translate the conversation into a provider request (tool/function calling).
* Validate the model's tool output against the domain schema before it can
  reach the UI or the database - the model is treated as untrusted input.
* Protect the shared LLM quota with a per-user sliding-window rate limit.
* Never log prompt content (it may contain commercially sensitive plans).
"""

from __future__ import annotations

import threading
import time
from collections import defaultdict, deque
from datetime import date
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict
from pydantic import ValidationError as PydanticValidationError

from backend.config import Settings
from backend.domain.models import Project, Task, UserPrincipal
from backend.errors import AIProviderError, ConfigurationError, QuotaExceededError
from backend.logging_config import get_logger
from backend.services.llm_client import build_client

logger = get_logger(__name__)

TOOL_NAME = "update_gantt_chart"

_SYSTEM_INSTRUCTION = """\
You are the project planning assistant inside an enterprise Gantt chart tool.
Today's date is {today}.

Behaviour rules:
* Produce realistic, dependency-aware delivery plans using finish-to-start links.
* Prefer 5-15 tasks. Use milestones (zero duration) for go-live and sign-off gates.
* Task ids must be T1, T2, T3 ... and dependencies must reference existing ids only.
* Never invent progress figures for work that has not started; use 0.
* When the user asks to change the existing plan, return the COMPLETE updated task
  list - the tool call replaces the chart entirely.
* Call the `{tool}` tool whenever you have enough information to draw or update a
  chart. Otherwise ask one concise clarifying question.
* Keep prose answers under 80 words.

Current chart state (JSON):
{context}
"""


class ChatMessage(BaseModel):
    """One turn in the planning conversation."""

    model_config = ConfigDict(frozen=True)

    role: Literal["user", "assistant", "tool"]
    text: str = ""
    tool_name: str = ""
    tool_args: dict[str, Any] | None = None
    tool_response: dict[str, Any] | None = None


class PlanProposal(BaseModel):
    """A validated chart update emitted by the model."""

    model_config = ConfigDict(frozen=True)

    project_name: str
    tasks: tuple[Task, ...]


class AssistantReply(BaseModel):
    """What the service hands back to the frontend."""

    model_config = ConfigDict(frozen=True)

    text: str = ""
    proposal: PlanProposal | None = None


class _SlidingWindowRateLimiter:
    """In-process per-subject limiter.

    Sufficient for a single Cloud Run instance. For multi-instance deployments
    swap this for a shared counter (Redis / Memorystore) behind the same API.
    """

    def __init__(self, max_calls: int, window_seconds: float = 60.0) -> None:
        self._max = max_calls
        self._window = window_seconds
        self._hits: dict[str, deque[float]] = defaultdict(deque)
        self._lock = threading.Lock()

    def check(self, key: str) -> None:
        now = time.monotonic()
        with self._lock:
            hits = self._hits[key]
            while hits and now - hits[0] > self._window:
                hits.popleft()
            if len(hits) >= self._max:
                raise QuotaExceededError(
                    "You have reached the AI request limit for this minute. "
                    "Please wait a moment and try again."
                )
            hits.append(now)


class AIPlanningService:
    """Thin, testable wrapper around the Vertex AI generative API."""

    def __init__(self, settings: Settings) -> None:
        self._llm = settings.llm
        self._client: Any | None = None
        self._client_lock = threading.Lock()
        self._limiter = _SlidingWindowRateLimiter(settings.llm.rate_limit_per_minute)

    @property
    def enabled(self) -> bool:
        return self._llm.enabled

    # -- Public API --------------------------------------------------------

    def complete(
        self,
        messages: list[ChatMessage],
        project: Project,
        principal: UserPrincipal,
    ) -> AssistantReply:
        if not self.enabled:
            raise ConfigurationError(
                "The AI assistant is disabled. Set llm.enabled = true in the configuration file."
            )
        self._limiter.check(principal.subject)

        from google.genai import types  # local import keeps module import cheap

        response = self._generate(
            contents=self._to_contents(messages),
            config=types.GenerateContentConfig(
                system_instruction=self._system_instruction(project),
                temperature=self._llm.temperature,
                max_output_tokens=self._llm.max_output_tokens,
                tools=[types.Tool(function_declarations=[self._tool_declaration()])],
                automatic_function_calling=types.AutomaticFunctionCallingConfig(disable=True),
            ),
        )

        calls = getattr(response, "function_calls", None) or []
        if calls:
            proposal = self._parse_proposal(dict(calls[0].args or {}))
            if proposal is not None:
                logger.info(
                    "ai_plan_generated",
                    extra={"task_count": len(proposal.tasks), "actor": principal.subject},
                )
                return AssistantReply(
                    text="I have updated the chart with the proposed timeline.",
                    proposal=proposal,
                )
            return AssistantReply(
                text=(
                    "I generated a plan but it failed validation, so the chart was not "
                    "changed. Please restate the requirements and I will try again."
                )
            )

        return AssistantReply(text=(getattr(response, "text", "") or "").strip())

    # -- Internals ---------------------------------------------------------

    def _ensure_client(self) -> Any:
        with self._client_lock:
            if self._client is None:
                self._client = build_client(self._llm)
            return self._client

    def _generate(self, *, contents: list[Any], config: Any) -> Any:
        # Built outside the try block so configuration problems keep their own message.
        client = self._ensure_client()
        try:
            return client.models.generate_content(
                model=self._llm.model, contents=contents, config=config
            )
        except Exception as exc:  # noqa: BLE001 - provider raises many types
            logger.warning("ai_request_failed", extra={"error_type": type(exc).__name__})
            raise AIProviderError from exc

    def _system_instruction(self, project: Project) -> str:
        context = project.model_dump_json(
            include={"name", "view_mode", "tasks"}, exclude_none=True
        )
        # Guard the prompt budget on very large charts.
        if len(context) > 24_000:
            context = context[:24_000] + "...(truncated)"
        return _SYSTEM_INSTRUCTION.format(
            today=date.today().isoformat(), tool=TOOL_NAME, context=context
        )

    @staticmethod
    def _to_contents(messages: list[ChatMessage]) -> list[Any]:
        from google.genai import types

        contents: list[Any] = []
        for message in messages:
            if message.role == "user":
                contents.append(
                    types.Content(role="user", parts=[types.Part(text=message.text)])
                )
            elif message.role == "assistant":
                if message.tool_args is not None:
                    contents.append(
                        types.Content(
                            role="model",
                            parts=[
                                types.Part.from_function_call(
                                    name=message.tool_name or TOOL_NAME,
                                    args=message.tool_args,
                                )
                            ],
                        )
                    )
                elif message.text:
                    contents.append(
                        types.Content(role="model", parts=[types.Part(text=message.text)])
                    )
            elif message.role == "tool":
                contents.append(
                    types.Content(
                        role="user",
                        parts=[
                            types.Part.from_function_response(
                                name=message.tool_name or TOOL_NAME,
                                response=message.tool_response or {"status": "ok"},
                            )
                        ],
                    )
                )
        return contents

    @staticmethod
    def _tool_declaration() -> Any:
        from google.genai import types

        string = types.Schema(type=types.Type.STRING)
        return types.FunctionDeclaration(
            name=TOOL_NAME,
            description=(
                "Replace the Gantt chart with a complete, dependency-ordered task list."
            ),
            parameters=types.Schema(
                type=types.Type.OBJECT,
                properties={
                    "projectName": types.Schema(
                        type=types.Type.STRING, description="Short project title."
                    ),
                    "tasks": types.Schema(
                        type=types.Type.ARRAY,
                        items=types.Schema(
                            type=types.Type.OBJECT,
                            properties={
                                "id": types.Schema(
                                    type=types.Type.STRING,
                                    description="Task id in the form T1, T2, T3.",
                                ),
                                "name": string,
                                "startDate": types.Schema(
                                    type=types.Type.STRING, description="YYYY-MM-DD"
                                ),
                                "endDate": types.Schema(
                                    type=types.Type.STRING,
                                    description="YYYY-MM-DD; equals startDate for milestones.",
                                ),
                                "owner": types.Schema(
                                    type=types.Type.STRING,
                                    description="Accountable team or role.",
                                ),
                                "workstream": types.Schema(
                                    type=types.Type.STRING,
                                    description="Optional grouping, e.g. Platform, Assurance.",
                                ),
                                "dependencies": types.Schema(
                                    type=types.Type.ARRAY,
                                    items=string,
                                    description="Ids of predecessor tasks.",
                                ),
                                "isMilestone": types.Schema(type=types.Type.BOOLEAN),
                                "progress": types.Schema(
                                    type=types.Type.INTEGER, description="0-100"
                                ),
                                "color": types.Schema(
                                    type=types.Type.STRING,
                                    description="Hex colour, e.g. #E60000.",
                                ),
                            },
                            required=[
                                "id", "name", "startDate", "endDate", "owner",
                                "dependencies", "isMilestone", "progress", "color",
                            ],
                        ),
                    ),
                },
                required=["projectName", "tasks"],
            ),
        )

    @staticmethod
    def _parse_proposal(args: dict[str, Any]) -> PlanProposal | None:
        """Validate untrusted model output into domain objects."""
        raw_tasks = args.get("tasks") or []
        tasks: list[Task] = []
        for index, raw in enumerate(raw_tasks, start=1):
            if not isinstance(raw, dict):
                continue
            try:
                tasks.append(
                    Task(
                        ref=str(raw.get("id") or f"T{index}").upper(),
                        name=str(raw.get("name") or f"Task {index}")[:200],
                        start_date=date.fromisoformat(str(raw["startDate"])[:10]),
                        end_date=date.fromisoformat(str(raw["endDate"])[:10]),
                        owner=str(raw.get("owner") or "")[:120],
                        workstream=str(raw.get("workstream") or "")[:120],
                        dependencies=raw.get("dependencies") or (),
                        is_milestone=bool(raw.get("isMilestone", False)),
                        progress=int(raw.get("progress") or 0),
                        color=str(raw.get("color") or ""),
                        notes="",
                    )
                )
            except (KeyError, ValueError, TypeError, PydanticValidationError):
                logger.warning("ai_task_rejected", extra={"index": index})
                continue

        if not tasks:
            return None
        return PlanProposal(
            project_name=str(args.get("projectName") or "AI Project")[:200],
            tasks=tuple(tasks),
        )
