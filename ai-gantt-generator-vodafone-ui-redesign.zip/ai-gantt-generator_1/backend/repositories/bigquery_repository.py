"""BigQuery repository - planned successor to the SQLite implementation.

The class is intentionally a documented stub: it pins the interface, the table
layout and the write strategy so the migration is a configuration change
(``DATABASE_BACKEND=bigquery``) plus the implementation of these methods, with
zero impact on services or the frontend.

Implementation plan
-------------------
Dataset ``{BIGQUERY_PROJECT_ID}.{BIGQUERY_DATASET}`` with the tables defined in
``backend/db/db.sql`` (see the migration notes at the top of that file).

* Reads   - parameterised ``google.cloud.bigquery.QueryJobConfig`` queries;
            never f-string interpolation of user input.
* Writes  - ``MERGE`` on the natural keys inside a multi-statement transaction
            (``BEGIN TRANSACTION`` / ``COMMIT``) so a project, its tasks and its
            dependency edges are replaced atomically.
* Concurrency - the optimistic ``version`` column is checked in the ``MERGE``
            predicate; a zero-row update means another writer won the race and
            must raise :class:`~backend.errors.ConcurrencyError`.
* Caching - project list queries are small and frequent; front them with a
            short-lived cache to control slot usage and cost.
* Identity - run under a dedicated service account with
            ``roles/bigquery.dataEditor`` scoped to the dataset only.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from backend.config import Settings
from backend.domain.models import (
    AuditAction,
    Project,
    ProjectRole,
    ProjectSummary,
    UserPrincipal,
)

_NOT_IMPLEMENTED = (
    "The BigQuery backend is not implemented yet. "
    "Set database.backend = 'sqlite' in the configuration file until the migration is complete."
)


class BigQueryProjectRepository:
    """Placeholder satisfying :class:`~backend.repositories.base.ProjectRepository`."""

    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        bigquery = settings.database.bigquery
        self._dataset = f"{bigquery.project_id}.{bigquery.dataset}"

    @property
    def dataset(self) -> str:
        return self._dataset

    def upsert_user(self, principal: UserPrincipal) -> None:
        raise NotImplementedError(_NOT_IMPLEMENTED)

    def list_projects(self, principal: UserPrincipal) -> list[ProjectSummary]:
        raise NotImplementedError(_NOT_IMPLEMENTED)

    def get_project(self, project_id: str, principal: UserPrincipal) -> Project | None:
        raise NotImplementedError(_NOT_IMPLEMENTED)

    def get_role(self, project_id: str, principal: UserPrincipal) -> ProjectRole | None:
        raise NotImplementedError(_NOT_IMPLEMENTED)

    def save_project(
        self, project: Project, principal: UserPrincipal, *, expected_version: int | None
    ) -> Project:
        raise NotImplementedError(_NOT_IMPLEMENTED)

    def soft_delete_project(self, project_id: str, principal: UserPrincipal) -> None:
        raise NotImplementedError(_NOT_IMPLEMENTED)

    def list_revisions(
        self, project_id: str, principal: UserPrincipal, limit: int = 25
    ) -> list[tuple[int, datetime, str]]:
        raise NotImplementedError(_NOT_IMPLEMENTED)

    def get_revision(
        self, project_id: str, version: int, principal: UserPrincipal
    ) -> Project | None:
        raise NotImplementedError(_NOT_IMPLEMENTED)


class BigQueryAuditRepository:
    """Placeholder audit sink - target: streaming inserts into ``audit_log``."""

    def __init__(self, settings: Settings) -> None:
        self._settings = settings

    def record(
        self,
        *,
        principal: UserPrincipal,
        action: AuditAction,
        resource_id: str = "",
        resource_type: str = "project",
        outcome: str = "success",
        details: dict[str, Any] | None = None,
    ) -> None:
        raise NotImplementedError(_NOT_IMPLEMENTED)
