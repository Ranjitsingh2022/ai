"""Application configuration, loaded from a single TOML file.

Everything an operator may need to change - LLM endpoint/gateway, network proxy,
authentication for the LLM and for end users, database and limits - lives in
one file: ``config/app.toml`` (override the location with ``APP_CONFIG_FILE``).

Secrets never need to be written into the file. Any secret value may instead be
a reference that is resolved when it is used:

* ``env:NAME``   - read from the environment variable ``NAME``
* ``file:/path`` - read from a file (Secret Manager / Kubernetes volume mounts)

In staging and production, literal secrets are rejected. Unknown keys are
rejected too, so a typo in the file fails at start-up instead of being ignored.
"""

from __future__ import annotations

import os
import sys
from functools import lru_cache
from pathlib import Path
from typing import Literal
from urllib.parse import urlparse

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib

from pydantic import BaseModel, ConfigDict, Field, SecretStr, field_validator, model_validator
from pydantic import ValidationError as PydanticValidationError

from backend.errors import ConfigurationError

Environment = Literal["local", "development", "staging", "production"]
DatabaseBackend = Literal["sqlite", "bigquery"]
AuthProviderName = Literal["local", "entra_id"]
LlmAuthMethod = Literal[
    "adc", "id_token", "service_account_file", "impersonation", "gateway_token", "none"
]

CONFIG_FILE_ENV = "APP_CONFIG_FILE"

_REPO_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG_PATH = _REPO_ROOT / "config" / "app.toml"

_SECRET_REF_PREFIXES = ("env:", "file:")
_LOCAL_HOSTS = frozenset({"localhost", "127.0.0.1", "::1"})


# -- Secret references ---------------------------------------------------------


def is_secret_ref(value: str) -> bool:
    return value.startswith(_SECRET_REF_PREFIXES)


def resolve_ref(value: str) -> str:
    """Resolve an ``env:`` / ``file:`` reference. Any other value is returned unchanged."""
    if value.startswith("env:"):
        name = value[4:].strip()
        resolved = os.environ.get(name, "").strip()
        if not resolved:
            raise ConfigurationError(
                f"The environment variable '{name}' referenced by the configuration is not set."
            )
        return resolved
    if value.startswith("file:"):
        path = Path(value[5:].strip())
        try:
            content = path.read_text(encoding="utf-8").strip()
        except OSError as exc:
            raise ConfigurationError(
                f"The secret file '{path}' referenced by the configuration cannot be read."
            ) from exc
        if not content:
            raise ConfigurationError(f"The secret file '{path}' is empty.")
        return content
    return value


def resolve_secret(value: SecretStr | None) -> str | None:
    return None if value is None else resolve_ref(value.get_secret_value())


# -- Sections ------------------------------------------------------------------


class _Section(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class AppSection(_Section):
    name: str = "AI Gantt Generator"
    environment: Environment = "local"
    version: str = "2.0.0"
    log_level: str = "INFO"
    log_format: Literal["json", "text"] = "json"

    @field_validator("log_level")
    @classmethod
    def _upper_log_level(cls, value: str) -> str:
        level = value.upper()
        if level not in {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}:
            raise ValueError(f"Unsupported log level: {value}")
        return level


class LimitsSection(_Section):
    max_tasks_per_project: int = Field(default=300, ge=1, le=5000)
    max_projects_per_user: int = Field(default=200, ge=1)
    revision_history_limit: int = Field(default=25, ge=1)


class BigQuerySection(_Section):
    project_id: str = ""
    dataset: str = "gantt"
    location: str = "EU"


class DatabaseSection(_Section):
    backend: DatabaseBackend = "sqlite"
    sqlite_path: Path = Path("data/gantt.db")
    bigquery: BigQuerySection = BigQuerySection()

    @field_validator("sqlite_path")
    @classmethod
    def _anchor_relative_path(cls, value: Path) -> Path:
        return value if value.is_absolute() else _REPO_ROOT / value


class LlmGatewaySection(_Section):
    """Optional enterprise LLM gateway/proxy that fronts Vertex AI."""

    url: str = ""
    api_version: str = ""
    headers: dict[str, str] = Field(default_factory=dict)


class LlmNetworkSection(_Section):
    """Outbound network settings for reaching Vertex AI or the gateway."""

    forward_proxy: str = ""
    ca_bundle: str = ""


class LlmAuthSection(_Section):
    method: LlmAuthMethod = "adc"
    service_account: str = ""
    service_account_file: str = ""
    audience: str = ""
    token: SecretStr | None = None

    @field_validator("token", mode="before")
    @classmethod
    def _blank_token_is_none(cls, value: object) -> object:
        return None if value in ("", None) else value


class LlmSection(_Section):
    enabled: bool = False
    project_id: str = ""
    location: str = "europe-west4"
    model: str = "gemini-2.5-flash"
    timeout_seconds: float = Field(default=60.0, gt=0, le=600)
    max_retries: int = Field(default=2, ge=0, le=6)
    rate_limit_per_minute: int = Field(default=20, ge=1, le=600)
    temperature: float = Field(default=0.3, ge=0, le=2)
    max_output_tokens: int = Field(default=4096, ge=256, le=65535)
    gateway: LlmGatewaySection = LlmGatewaySection()
    network: LlmNetworkSection = LlmNetworkSection()
    auth: LlmAuthSection = LlmAuthSection()


class LocalAuthSection(_Section):
    user_email: str = "local.developer@example.com"
    tenant_id: str = "local-tenant"


class EntraSection(_Section):
    tenant_id: str = ""
    client_id: str = ""
    client_secret: SecretStr | None = None
    redirect_uri: str = ""
    scopes: tuple[str, ...] = ("User.Read",)

    @field_validator("client_secret", mode="before")
    @classmethod
    def _blank_secret_is_none(cls, value: object) -> object:
        return None if value in ("", None) else value


class AuthSection(_Section):
    provider: AuthProviderName = "local"
    local: LocalAuthSection = LocalAuthSection()
    entra: EntraSection = EntraSection()


# -- Root ----------------------------------------------------------------------


class Settings(_Section):
    """Typed, validated runtime configuration."""

    app: AppSection = AppSection()
    llm: LlmSection = LlmSection()
    database: DatabaseSection = DatabaseSection()
    auth: AuthSection = AuthSection()
    limits: LimitsSection = LimitsSection()

    @property
    def is_production(self) -> bool:
        return self.app.environment in ("staging", "production")

    @property
    def ai_enabled(self) -> bool:
        return self.llm.enabled

    @model_validator(mode="after")
    def _validate_wiring(self) -> Settings:
        problems: list[str] = []
        self._check_llm(problems)
        self._check_auth(problems)
        if self.database.backend == "bigquery" and not self.database.bigquery.project_id:
            problems.append("database.bigquery.project_id is required when database.backend = 'bigquery'")
        if problems:
            raise ValueError("; ".join(problems))
        return self

    def _check_llm(self, problems: list[str]) -> None:
        llm = self.llm
        if not llm.enabled:
            return

        auth = llm.auth
        if auth.method == "service_account_file" and not auth.service_account_file:
            problems.append("llm.auth.service_account_file is required for method 'service_account_file'")
        if auth.method == "impersonation" and not auth.service_account:
            problems.append("llm.auth.service_account is required for method 'impersonation'")
        if auth.method == "id_token" and not (auth.audience or llm.gateway.url):
            problems.append("llm.auth.audience (or llm.gateway.url) is required for method 'id_token'")
        if auth.method == "gateway_token" and auth.token is None:
            problems.append("llm.auth.token is required for method 'gateway_token'")
        if auth.method in ("id_token", "gateway_token", "none") and not llm.project_id:
            problems.append(f"llm.project_id is required for method '{auth.method}'")

        if llm.gateway.url:
            parsed = urlparse(llm.gateway.url)
            local_http = (
                parsed.scheme == "http" and parsed.hostname in _LOCAL_HOSTS and not self.is_production
            )
            if not parsed.hostname or (parsed.scheme != "https" and not local_http):
                problems.append("llm.gateway.url must be an https:// URL")

        proxy = llm.network.forward_proxy
        if proxy and not is_secret_ref(proxy):
            if urlparse(proxy).scheme not in {"http", "https", "socks5", "socks5h"}:
                problems.append("llm.network.forward_proxy must be an http(s):// or socks5:// URL")

        if auth.token is not None:
            self._check_secret("llm.auth.token", auth.token, problems)

    def _check_auth(self, problems: list[str]) -> None:
        if self.is_production and self.auth.provider == "local":
            problems.append("auth.provider = 'local' is not permitted in staging or production")
        if self.auth.provider != "entra_id":
            return

        entra = self.auth.entra
        for name, value in (
            ("tenant_id", entra.tenant_id),
            ("client_id", entra.client_id),
            ("redirect_uri", entra.redirect_uri),
        ):
            if not value:
                problems.append(f"auth.entra.{name} is required when auth.provider = 'entra_id'")
        if entra.client_secret is None:
            problems.append("auth.entra.client_secret is required when auth.provider = 'entra_id'")
        else:
            self._check_secret("auth.entra.client_secret", entra.client_secret, problems)

    def _check_secret(self, field: str, value: SecretStr, problems: list[str]) -> None:
        reference = value.get_secret_value()
        if self.is_production and not is_secret_ref(reference):
            problems.append(f"{field} must be an 'env:' or 'file:' reference in staging/production")
            return
        try:
            resolve_ref(reference)
        except ConfigurationError as exc:
            problems.append(f"{field}: {exc.message}")


# -- Loading -------------------------------------------------------------------


def resolve_config_path(path: Path | str | None = None) -> Path | None:
    """Explicit path > ``APP_CONFIG_FILE`` > ``config/app.toml`` (if present)."""
    explicit = path or os.environ.get(CONFIG_FILE_ENV)
    if explicit:
        candidate = Path(explicit).expanduser()
        if not candidate.is_file():
            raise ConfigurationError(f"Configuration file not found: {candidate}")
        return candidate
    return DEFAULT_CONFIG_PATH if DEFAULT_CONFIG_PATH.is_file() else None


def _describe(config_path: Path | None, exc: PydanticValidationError) -> str:
    # Only field paths and messages are reported; input values may be secrets.
    lines = [
        f"{'.'.join(str(part) for part in err['loc']) or '(root)'}: {err['msg']}"
        for err in exc.errors(include_input=False, include_url=False)
    ]
    return f"Invalid configuration in {config_path or 'defaults'}: " + " | ".join(lines)


def load_settings(path: Path | str | None = None) -> Settings:
    """Read and validate the configuration file."""
    config_path = resolve_config_path(path)
    raw: dict[str, object] = {}
    if config_path is not None:
        try:
            with config_path.open("rb") as handle:
                raw = tomllib.load(handle)
        except tomllib.TOMLDecodeError as exc:
            raise ConfigurationError(f"{config_path} is not valid TOML: {exc}") from exc
    try:
        return Settings.model_validate(raw)
    except PydanticValidationError as exc:
        raise ConfigurationError(_describe(config_path, exc)) from exc


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return the process-wide settings singleton."""
    return load_settings()
