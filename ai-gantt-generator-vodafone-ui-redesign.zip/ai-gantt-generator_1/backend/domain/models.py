"""Core domain models.

These Pydantic models are the single source of truth for the shape of a
project. They are validated at every boundary (AI output, database rows, user
input) which keeps the rest of the code free of defensive checks.
"""

from __future__ import annotations

import re
import sys
import uuid
from datetime import date, datetime, timezone
from typing import Annotated, Any

UTC = timezone.utc

if sys.version_info >= (3, 11):
    from enum import StrEnum
    from typing import Self
else:
    from enum import Enum
    from typing_extensions import Self
    
    class StrEnum(str, Enum):
        """Backport of StrEnum for Python < 3.11."""
        def __str__(self) -> str:
            return self.value

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    StringConstraints,
    computed_field,
    field_validator,
    model_validator,
)

HEX_COLOR_RE = re.compile(r"^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$")
TASK_REF_RE = re.compile(r"^T\d{1,4}$")

DEFAULT_TASK_COLOR = "#E60000"

TaskRef = Annotated[str, StringConstraints(pattern=r"^T\d{1,4}$")]
NonEmptyStr = Annotated[str, StringConstraints(min_length=1, max_length=200, strip_whitespace=True)]


class ViewMode(StrEnum):
    DAYS = "days"
    WEEKS = "weeks"
    WEEK_COUNT = "week_count"
    MONTHS = "months"
    QUARTERS = "quarters"


class ProjectRole(StrEnum):
    OWNER = "owner"
    EDITOR = "editor"
    VIEWER = "viewer"

    @property
    def can_edit(self) -> bool:
        return self in (ProjectRole.OWNER, ProjectRole.EDITOR)

    @property
    def can_delete(self) -> bool:
        return self is ProjectRole.OWNER


class AuditAction(StrEnum):
    PROJECT_CREATED = "project.created"
    PROJECT_UPDATED = "project.updated"
    PROJECT_DELETED = "project.deleted"
    PROJECT_RESTORED = "project.restored"
    PROJECT_EXPORTED = "project.exported"
    AI_PLAN_GENERATED = "ai.plan_generated"
    USER_SIGNED_IN = "user.signed_in"


class UserPrincipal(BaseModel):
    """The authenticated caller. Produced by an :mod:`backend.auth` provider."""

    model_config = ConfigDict(frozen=True)

    subject: NonEmptyStr
    tenant_id: NonEmptyStr
    email: str = ""
    display_name: str = ""
    roles: tuple[str, ...] = ()
    auth_provider: str = "local"

    @computed_field  # type: ignore[prop-decorator]
    @property
    def label(self) -> str:
        return self.display_name or self.email or self.subject


class Task(BaseModel):
    """A single schedule row. ``ref`` is the human-facing id (``T1``, ``T2``)."""

    model_config = ConfigDict(validate_assignment=True, extra="ignore")

    ref: TaskRef
    name: NonEmptyStr = "Untitled task"
    start_date: date
    end_date: date
    owner: Annotated[str, StringConstraints(max_length=120, strip_whitespace=True)] = ""
    workstream: Annotated[str, StringConstraints(max_length=120, strip_whitespace=True)] = ""
    dependencies: tuple[TaskRef, ...] = ()
    is_milestone: bool = False
    progress: int = Field(default=0, ge=0, le=100)
    color: str = DEFAULT_TASK_COLOR
    notes: Annotated[str, StringConstraints(max_length=2000)] = ""

    @field_validator("color")
    @classmethod
    def _validate_color(cls, value: str) -> str:
        value = (value or "").strip() or DEFAULT_TASK_COLOR
        if not HEX_COLOR_RE.match(value):
            return DEFAULT_TASK_COLOR
        return value.upper()

    @field_validator("dependencies", mode="before")
    @classmethod
    def _coerce_dependencies(cls, value: Any) -> tuple[str, ...]:
        if value is None:
            return ()
        if isinstance(value, str):
            parts = [p.strip().upper() for p in re.split(r"[,\s;]+", value)]
        else:
            parts = [str(p).strip().upper() for p in value]
        # Deduplicate while preserving order; drop anything that is not a ref.
        seen: dict[str, None] = {}
        for part in parts:
            if part and TASK_REF_RE.match(part):
                seen.setdefault(part, None)
        return tuple(seen)

    @model_validator(mode="after")
    def _enforce_invariants(self) -> Self:
        # A milestone is a zero-duration point in time.
        if self.is_milestone and self.end_date != self.start_date:
            object.__setattr__(self, "end_date", self.start_date)
        if self.end_date < self.start_date:
            object.__setattr__(self, "end_date", self.start_date)
        if self.ref in self.dependencies:
            object.__setattr__(
                self, "dependencies", tuple(d for d in self.dependencies if d != self.ref)
            )
        return self

    @property
    def duration_days(self) -> int:
        """Inclusive calendar duration. Milestones are 0."""
        if self.is_milestone:
            return 0
        return (self.end_date - self.start_date).days + 1

    @property
    def is_complete(self) -> bool:
        return self.progress >= 100


def prune_dangling_dependencies(tasks: tuple[Task, ...]) -> tuple[Task, ...]:
    """Drop dependency references that no longer resolve to a task."""
    known = {task.ref for task in tasks}
    cleaned: list[Task] = []
    changed = False
    for task in tasks:
        kept = tuple(dep for dep in task.dependencies if dep in known)
        if kept != task.dependencies:
            changed = True
            cleaned.append(task.model_copy(update={"dependencies": kept}))
        else:
            cleaned.append(task)
    return tuple(cleaned) if changed else tasks


class Project(BaseModel):
    """Aggregate root. Owns its tasks and enforces referential integrity."""
    model_config = ConfigDict(validate_assignment=True, extra="ignore")

    project_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    tenant_id: str = ""
    name: NonEmptyStr = "New Project"
    description: Annotated[str, StringConstraints(max_length=1000)] = ""
    view_mode: ViewMode = ViewMode.MONTHS
    tasks: tuple[Task, ...] = ()

    owner_subject: str = ""
    version: int = Field(default=0, ge=0)
    created_at: datetime | None = None
    created_by: str = ""
    updated_at: datetime | None = None
    updated_by: str = ""

    @model_validator(mode="after")
    def _drop_dangling_dependencies(self) -> Self:
        pruned = prune_dangling_dependencies(self.tasks)
        if pruned is not self.tasks:
            object.__setattr__(self, "tasks", pruned)
        return self

    # -- Helpers -----------------------------------------------------------

    def task_by_ref(self, ref: str) -> Task | None:
        return next((t for t in self.tasks if t.ref == ref), None)

    def next_ref(self) -> str:
        used = {
            int(t.ref[1:]) for t in self.tasks if TASK_REF_RE.match(t.ref)
        }
        return f"T{(max(used) + 1) if used else 1}"

    def with_tasks(self, tasks: list[Task] | tuple[Task, ...]) -> Project:
        # model_copy bypasses validators, so integrity is restored explicitly.
        return self.model_copy(
            update={"tasks": prune_dangling_dependencies(tuple(tasks))}
        )

    def touch(self, principal: UserPrincipal) -> Project:
        now = datetime.now(tz=UTC)
        return self.model_copy(
            update={
                "updated_at": now,
                "updated_by": principal.subject,
                "created_at": self.created_at or now,
                "created_by": self.created_by or principal.subject,
                "owner_subject": self.owner_subject or principal.subject,
                "tenant_id": self.tenant_id or principal.tenant_id,
            }
        )


class ProjectSummary(BaseModel):
    """Lightweight listing projection - avoids loading every task."""

    model_config = ConfigDict(frozen=True)

    project_id: str
    name: str
    description: str = ""
    task_count: int = 0
    updated_at: datetime | None = None
    updated_by: str = ""
    role: ProjectRole = ProjectRole.VIEWER


class ProjectStats(BaseModel):
    """Derived schedule metrics shown in the dashboard strip."""

    model_config = ConfigDict(frozen=True)

    task_count: int = 0
    milestone_count: int = 0
    total_days: int = 0
    start_date: date | None = None
    end_date: date | None = None
    completion_pct: int = 0
    overdue_count: int = 0
    critical_path_refs: tuple[str, ...] = ()
    unique_owners: int = 0


class ValidationIssue(BaseModel):
    """A non-fatal schedule problem surfaced to the user."""

    model_config = ConfigDict(frozen=True)

    severity: str = "warning"
    code: str
    message: str
    task_refs: tuple[str, ...] = ()
