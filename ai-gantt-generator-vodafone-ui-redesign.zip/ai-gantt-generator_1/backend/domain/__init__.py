"""Domain layer: pure business models and algorithms, no I/O."""
