"""Backend exception hierarchy.

Every error raised across a service boundary derives from :class:`AppError` so
the presentation layer can render a safe, user-facing message without leaking
internal detail.
"""

from __future__ import annotations


class AppError(Exception):
    """Base class for all application errors."""

    user_message = "An unexpected error occurred. Please try again."

    def __init__(self, message: str | None = None) -> None:
        super().__init__(message or self.user_message)
        self.message = message or self.user_message


class ConfigurationError(AppError):
    user_message = "The application is not configured correctly. Contact an administrator."


class ValidationError(AppError):
    user_message = "The submitted data is invalid."


class NotFoundError(AppError):
    user_message = "The requested item does not exist."


class AuthenticationError(AppError):
    user_message = "You must sign in to continue."


class AuthorizationError(AppError):
    user_message = "You do not have permission to perform this action."


class ConcurrencyError(AppError):
    user_message = (
        "This project was changed by someone else since you loaded it. "
        "Reload the project and reapply your changes."
    )


class QuotaExceededError(AppError):
    user_message = "A usage limit was reached. Please try again shortly."


class AIProviderError(AppError):
    user_message = "The AI assistant is temporarily unavailable. Please try again."


class StorageError(AppError):
    user_message = "The data store is unavailable. Please try again."
