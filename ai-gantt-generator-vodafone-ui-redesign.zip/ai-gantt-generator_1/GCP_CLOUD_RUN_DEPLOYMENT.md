# Google Cloud Run Deployment Guide

**Application:** AI Gantt Generator
**Runtime:** Python 3.12 · Streamlit (no Node.js)
**Target:** Google Cloud Run (fully managed)
**Hardening:** multi-stage image, non-root uid 10001, Secret Manager, health
probes, structured JSON logging, optional Entra ID SSO.

---

## 1. Architecture on Cloud Run

| Concern | Implementation |
| --- | --- |
| HTTP server | Streamlit (binds `0.0.0.0:$PORT`) |
| Health probe | `GET /_stcore/health` (built into Streamlit) |
| Frontend | `app/` — Streamlit views, Plotly chart |
| Backend | `backend/` — domain, services, repositories, auth |
| State | SQLite file (default) or BigQuery (`database.backend = "bigquery"`) |
| Configuration | One TOML file, mounted from Secret Manager at `/etc/gantt/app.toml` |
| LLM | Vertex AI via the service's own identity (Workload Identity) - no API key |
| Secrets | Secret Manager → environment variables, referenced as `env:NAME` in the file |
| Logs | Single-line JSON on stdout → Cloud Logging |

> **Statefulness warning.** SQLite lives on the container filesystem, which is
> ephemeral and per-instance. For anything beyond a single-instance pilot,
> either mount a Cloud Storage FUSE / Filestore volume at `/var/lib/gantt`
> **and pin `--max-instances=1`**, or move to BigQuery.

---

## 2. Prerequisites

```bash
gcloud services enable \
  run.googleapis.com \
  artifactregistry.googleapis.com \
  cloudbuild.googleapis.com \
  secretmanager.googleapis.com \
  aiplatform.googleapis.com

PROJECT_ID=$(gcloud config get-value project)

gcloud iam service-accounts create sa-ai-gantt-generator \
  --display-name="AI Gantt Generator runtime"

SA="sa-ai-gantt-generator@${PROJECT_ID}.iam.gserviceaccount.com"

# Lets the runtime identity call Vertex AI directly (method = "adc").
gcloud projects add-iam-policy-binding ${PROJECT_ID} \
  --member="serviceAccount:${SA}" --role="roles/aiplatform.user"
```

If you reach Vertex AI through the Cloud Run **LLM proxy** instead
(`method = "id_token"`), the identity that mints the ID token needs permission to
invoke that proxy, in the proxy's project:

```bash
gcloud run services add-iam-policy-binding <proxy-service> \
  --region=<proxy-region> --project=<proxy-project> \
  --member="serviceAccount:<service-account-from-config>" --role="roles/run.invoker"
```

When `llm.auth.service_account` is set, the Cloud Run runtime identity (`${SA}`)
additionally needs `roles/iam.serviceAccountTokenCreator` on that service account.

---

## 3. Configuration and secrets

All settings live in **one TOML file**. For Cloud Run, store the production copy
in Secret Manager and mount it as a file. Secrets *inside* it are references
(`env:NAME`), never literal values - the app refuses to start in
staging/production if a literal secret is found.

`app-config.toml` (production example):

```toml
[app]
environment = "production"
log_format = "json"

[llm]
enabled = true
project_id = "my-gcp-project"
location = "europe-west4"

[llm.auth]
method = "adc"            # Workload Identity of the Cloud Run service account

# Or: route through the Cloud Run LLM proxy with an ID token (replaces the block above)
# [llm]
# project_id = "my-lab-project"
# location = "europe-west1"
# [llm.gateway]
# url = "https://proxy-service-123456789.europe-west1.run.app/google-llm"
# api_version = "v1beta1"
# [llm.auth]
# method = "id_token"
# service_account = "my-lab-sa@my-lab-project.iam.gserviceaccount.com"
# audience = "https://proxy-service-123456789.europe-west1.run.app"
#
# Optional extras: [llm.network] forward_proxy / ca_bundle, [llm.gateway] headers
[database]
backend = "sqlite"
sqlite_path = "/var/lib/gantt/gantt.db"

[auth]
provider = "entra_id"

[auth.entra]
tenant_id = "<tenant-guid>"
client_id = "<app-guid>"
client_secret = "env:ENTRA_CLIENT_SECRET"
redirect_uri = "https://<service-url>/"
```

```bash
gcloud secrets create gantt-app-config --data-file=app-config.toml
printf '%s' "<entra-client-secret>" | gcloud secrets create entra-client-secret --data-file=-

for S in gantt-app-config entra-client-secret; do
  gcloud secrets add-iam-policy-binding ${S} \
    --member="serviceAccount:${SA}" --role="roles/secretmanager.secretAccessor"
done
```

To change configuration later, add a new secret version
(`gcloud secrets versions add gantt-app-config --data-file=app-config.toml`) and
deploy a new revision.

---

## 4. Build and deploy

```bash
REGION="europe-west2"
REPO="cloud-run-apps"
IMAGE="${REGION}-docker.pkg.dev/${PROJECT_ID}/${REPO}/ai-gantt-generator:latest"

gcloud artifacts repositories create ${REPO} \
  --repository-format=docker --location=${REGION} 2>/dev/null || true

gcloud builds submit --tag "${IMAGE}" .

gcloud run deploy ai-gantt-generator \
  --image="${IMAGE}" \
  --region="${REGION}" \
  --service-account="${SA}" \
  --set-secrets="/etc/gantt/app.toml=gantt-app-config:latest,ENTRA_CLIENT_SECRET=entra-client-secret:latest" \
  --memory=1Gi --cpu=1 \
  --min-instances=0 --max-instances=1 \
  --concurrency=40 --timeout=300 \
  --session-affinity \
  --no-allow-unauthenticated
```

Flags that matter:

| Flag | Reason |
| --- | --- |
| `--session-affinity` | Streamlit holds a WebSocket per session; sticky routing avoids reconnect churn. |
| `--timeout=300` | Long-lived WebSocket connections. |
| `--max-instances=1` | Required while SQLite is the store (single writer). |
| `--no-allow-unauthenticated` | Prefer IAP / IAM in front of the service. Use `--allow-unauthenticated` only when Entra ID SSO is enabled and you have accepted the exposure. |

---

## 5. Entra ID SSO

1. Cloud Run URLs are predictable: `https://<service>-<project-number>.<region>.run.app`.
   Use it as `redirect_uri` in the config before the first deploy.
2. Register the application in Entra ID and add a **Web** redirect URI equal to
   that URL (trailing slash included).
3. Grant delegated `User.Read` and admin-consent.
4. Fill `[auth.entra]` in the configuration file (section 3) and deploy a new
   revision.

The application refuses to start with `auth.provider = "local"` when
`app.environment` is staging or production, so SSO cannot be bypassed by
misconfiguration.

---

## 6. Moving to BigQuery

```bash
bq --location=EU mk --dataset ${PROJECT_ID}:gantt
```

Translate `backend/db/db.sql` using the migration notes at the top of that file,
implement `BigQueryProjectRepository`, grant the runtime service account
`roles/bigquery.dataEditor` **scoped to the dataset**, then change the
configuration file:

```toml
[database]
backend = "bigquery"

[database.bigquery]
project_id = "my-gcp-project"
dataset = "gantt"
```

and deploy a new revision with `--max-instances=10`.

`--max-instances` can be raised once the single-writer SQLite constraint is gone.

---

## 7. Local container validation

Copy `config/app.toml` and set `sqlite_path = "/var/lib/gantt/gantt.db"` (the
image runs as a non-root user that can only write there), then:

```bash
docker build -t ai-gantt-generator:local .

docker run --rm -p 8080:8080 \
  -v "$PWD/app-local.toml:/etc/gantt/app.toml:ro" \
  -v gantt-data:/var/lib/gantt \
  ai-gantt-generator:local

curl -f http://localhost:8080/_stcore/health   # expects "ok"
```

For `llm.auth.method = "adc"` on a workstation, also mount your ADC file and
point `GOOGLE_APPLICATION_CREDENTIALS` at it, or use a service account.

---

## 8. Operational reference

| Setting | Value | Notes |
| --- | --- | --- |
| Port | `$PORT` (8080) | Injected by Cloud Run. |
| Health path | `/_stcore/health` | Liveness and readiness. |
| Memory | 1 GiB | Plotly + python-pptx export headroom. |
| CPU | 1 vCPU | Export generation is the heaviest operation. |
| Concurrency | 40 | Each session holds a WebSocket. |
| Scaling | 0 → 1 (SQLite) / 0 → N (BigQuery) | See section 1. |
| Log format | JSON on stdout | Fields: `severity`, `logger`, `message`, plus context. |

### What is logged

Structured events only — `project_saved`, `ai_plan_generated`, `pptx_exported`,
`container_ready`, `oidc_state_mismatch`. **Prompt content, task names and
credentials are never logged.** The `audit_log` table is the authoritative record
of who changed what and when.

---

## 9. Image contents

The build context excludes `tests/`, `legacy/`, `data/`, `*.md` and all dotenv
files (see `.dockerignore`). The runtime image contains only `backend/`,
`app/`, `assets/`, `.streamlit/` and the virtualenv. The configuration file is
mounted at run time, never baked in.
