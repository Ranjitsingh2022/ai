"""Application entry point.

Run with::

    streamlit run app/main.py
"""

from __future__ import annotations

from pathlib import Path

import streamlit as st
from backend.container import Container
from backend.domain.models import Project, UserPrincipal
from backend.errors import AppError

from app import theme
from app.auth_gate import render_identity_panel, require_principal
from app.bootstrap import get_container
from app.session import session
from app.views import (
    chat_panel,
    gantt_view,
    header,
    history_view,
    insights_view,
    project_sidebar,
    task_editor,
)

_LOGO = Path(__file__).resolve().parents[1] / "assets" / "logo.png"


def main() -> None:
    st.set_page_config(
        page_title="AI Gantt Generator",
        page_icon=str(_LOGO) if _LOGO.exists() else "📊",
        layout="wide",
        initial_sidebar_state="expanded",
        menu_items={"about": "AI Gantt Generator — enterprise project timeline planning."},
    )
    theme.inject()

    container = _resolve_container()
    _render_brand(container)

    principal = require_principal()
    render_identity_panel()

    project = _current_project(container, principal)
    role = container.projects.role_for(project, principal)

    options = project_sidebar.render(project, principal, role)
    project = session.project or project  # the sidebar may have replaced it

    stats = container.projects.stats(project)
    issues = container.projects.validate(project)

    header.render(project, stats, role)

    timeline_tab, tasks_tab, insights_tab, history_tab = st.tabs(
        ["Timeline", "Tasks", "Insights", "History"]
    )
    with timeline_tab:
        gantt_view.render(project, stats, options)
    with tasks_tab:
        task_editor.render(project, editable=role.can_edit)
    with insights_tab:
        insights_view.render(project, issues)
    with history_tab:
        history_view.render(project, principal, role)

    chat_panel.render(project, principal, role)
    session.flush_toast()


# -- Helpers ------------------------------------------------------------------


def _resolve_container() -> Container:
    try:
        return get_container()
    except AppError as exc:
        st.error(str(exc))
        st.stop()
    except Exception:  # noqa: BLE001 - startup misconfiguration
        st.error("The application failed to start. Check the server logs for details.")
        st.stop()


def _render_brand(container: Container) -> None:
    with st.sidebar:
        if _LOGO.exists():
            st.image(str(_LOGO), width=44)
        st.markdown(f"### {container.settings.app.name}")


def _current_project(container: Container, principal: UserPrincipal) -> Project:
    project = session.project
    if project is None:
        project = container.projects.blank_project(principal)
        session.set_project(project, dirty=False)
    return project


if __name__ == "__main__":
    main()
